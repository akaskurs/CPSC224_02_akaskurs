/*
 ASSIGNMENT #2
 DUE DATE: 02/11/2019
 NAMES: DONOVAN FARAR & ANTHONY KASKURS
*/

package assignment2;
import java.util.*;
import java.lang.*;
import javax.swing.JOptionPane;


public class Assignment2 {

    
    //Main simply calls the menu function used to display the menu
    public static void main(String[] args) {
       menu();
       
    }
    

    //Menu. Accepts no input and returns nothing. Displays menu and asks user to make a selection. Assigns the final word to be guessed depending on the option user selects
    public static void menu() {
        int selection;
        String finalWord = " "; //holds the final word to be guessed by the user
        String userSelection = JOptionPane.showInputDialog("** HANGMAN**\n**************\nChoose from the following options: \n1: Play game from a randomly chosen word in a list\n2: Play game from a word entered by another user\n3: Exit Game\n");
        selection = Integer.parseInt(userSelection); //converts string to intger
        
        while(selection != 3) //loops as long as selection isnt 3.
        {
            if(selection == 1) //if this selection is chosen, user will get a randomly chosen word from predefined list.
            {
                finalWord = getWord(); 
            }    
        
            if(selection == 2) //if this selection is chosen, user 2 will input a word for user 1 to guess.
            {
                finalWord = haveUserTwoEnterWord();
            }
            
            playGame(finalWord); //calls the playgame function, which will take the final word and use it to start the game.
            
            userSelection = JOptionPane.showInputDialog("** HANGMAN**\n**************\nChoose from the following options: \n1: Play game from a randomly chosen word in a list\n2: Play game from a word entered by another user\n3: Exit Game\n");
            selection = Integer.parseInt(userSelection); //converts string to intger
            
        }
        
        JOptionPane.showMessageDialog(null, "Thank's for playing!");
        System.exit(0); //exits program
    }
    
    
    //getWord() randomly chooses a word out of the array of Strings to use as finalWord. (used if user selects option 1 from the menu)
    public static String getWord() {
        String[] wordList = new String[10]; //creates an array to store the strings
        wordList[0] = "dog";
        wordList[1] = "car";
        wordList[2] = "boat";
        wordList[3] = "speaker";
        wordList[4] = "graphics";
        wordList[5] = "programming";
        wordList[6] = "java";
        wordList[7] = "party";
        wordList[8] = "lights";
        wordList[9] = "goofy";
       
        Random rand = new Random(); //new random object
        int wordChoice = rand.nextInt(10);
        return wordList[wordChoice]; //returns word at random index
    }
    
    
    //havUserTwoEnterWord() accepts nothing, returns a String. Has user 2 enter word for user 1 to guess. Also, checks for valid word input from user 2.
    public static String haveUserTwoEnterWord() {
        
        String correctUserWord = " "; //stores the word to be returned if valid
        boolean isValidWord = false; //boolean marker set to false.
        while(isValidWord == false) //loops as long as word entered is invalid
        {
            String userTwoInputWord = JOptionPane.showInputDialog("User Two. Please enter a word for user one to guess: ");
            
            for(int i = 0; i < userTwoInputWord.length(); i++) //goes along the user-input word and checks to see if all the characters are between an ascii range
            {
                if( (userTwoInputWord.charAt(i) >= 65 && userTwoInputWord.charAt(i) <= 90) || (userTwoInputWord.charAt(i) >= 97 && userTwoInputWord.charAt(i) <= 122) )
                {
                    correctUserWord = userTwoInputWord;
                    isValidWord = true;
                }
                else
                {
                    isValidWord = false;
                    JOptionPane.showMessageDialog(null, "Please only use uppercase or lowercase characters");
                    break;
                }
            }
        }
        return correctUserWord;
    }
    
    
    //playGame accepts word as parameter and plays the game of hangman for that passed in word
    public static void playGame(String word)
    {
        int errorCounter = 0; //counts the number of missed words
        String guessedLetterString; //String variable to hold the input entered in the input dialog boxes
        char guessedLetterChar = ' '; //holds the character that the user enters as a guess
        int wordLength = 0; //keeps track of how big the length of the word is that was entered
        int missedLetter = 0; //keeps track of how many missed letters there are in each guess
        int numDashes = word.length(); //keeps track of how many dashes in the char array
        int numericGuessedLetter = 0; //helps convert between char and int when forcing entered characters into lowercase.
        
        String tempWord = word; //tempword is a string that helps facilitate translating String input into char array.
        
        char[] tempWordChars = tempWord.toCharArray(); //converts the string into an array of char values
        
        for(int i = 0; i < word.length(); i++) //counts the length of the word and assigns each character in tempWordChars to a dash
        {
            wordLength++; //counts lenth of word
            tempWordChars[i] = '-';
        }
        
        while(errorCounter <= 5) //a loop that continues the game as long as the max number of errors allowed has not been reached.
        {
            missedLetter = 0; //sets missedLetter to 0 after every loop iteration to reset.
            guessedLetterString = JOptionPane.showInputDialog("Please Enter a guess: ");
            guessedLetterChar = guessedLetterString.charAt(0); //will only accept the first char in the user's guess like normal hangman
            
            if(guessedLetterChar < 65 || ((guessedLetterChar > 90) && (guessedLetterChar < 97)) || (guessedLetterChar > 122))
            {
                JOptionPane.showMessageDialog(null, "Please enter a valid character"); //input validation
                continue;
            }
            
            for(int n = 0; n < word.length(); n++)
            {
                
                if( (guessedLetterChar == tempWord.charAt(n)) || (guessedLetterChar == (tempWord.charAt(n) + 32)) || (guessedLetterChar == (tempWord.charAt(n) - 32) ))
                {
                    if((((int)guessedLetterChar >= 65)) && ((int)guessedLetterChar <= 90)) //if the char guess is uppecase, we convert it to lowercase to make the output look cleaner.
                    {
                        numericGuessedLetter = (int)guessedLetterChar;
                        numericGuessedLetter = numericGuessedLetter + 32;
                        guessedLetterChar = (char)numericGuessedLetter;
                        tempWordChars[n] = guessedLetterChar;
                    }

                    tempWordChars[n] = guessedLetterChar;
                    numDashes--; //we decrease the amount of number of dashes to keep track of how many missing letters we still have
                    
                    
                }
                
                else //if the guessed letter doesn't match with the character at the spot, it will increase the number of missedLetters for each attempt.
                {
                    missedLetter++;
                }
            }
            
            if(missedLetter == wordLength) //checks to see if the number of missed letters is the same as the word length, if so we increment the errorCounter (which is the same as a strike)
            {
                errorCounter ++;
            }
            
            String convertedString = String.copyValueOf(tempWordChars); //we conveert tempWordChars to a string so its able to be used in an output box.
            JOptionPane.showMessageDialog(null, "HANGMAN\n *************\n" + convertedString + "\n You have " + errorCounter + " strikes");
            
            if(numDashes == 0) //if we dont have a dash, we exit the loop - signifying we got it correct. If we have dashes, the loop boolean at the top will check to see if we have reached max number of errors
            {
                break;
            }
            
        }
        
        if(errorCounter == 6)
        {
           loseMessage(tempWord); //calls loseMessage if player loses
           
        }
        else if(numDashes == 0 && errorCounter < 6) 
        {
            winMessage(); //calls winMessage if player wins
        }
    }
    
   
    //Accpets a string and displays that the user has lost and the correct word
    public static void loseMessage(String answer)
    {
        JOptionPane.showMessageDialog(null, "You have lost. The word was: " + answer);
        
    }
    
    
    //Outputs a win message
    public static void winMessage()
    {
        JOptionPane.showMessageDialog(null, "Congrats! You've won!");
    }
}
