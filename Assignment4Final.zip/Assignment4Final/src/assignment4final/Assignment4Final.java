/*

 */
package assignment4final;
import java.awt.event.*;
import java.awt.*;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.AWTException; 
import java.awt.Robot; 

public class Assignment4Final {  //This class handles the creation of the JFrame and the JPanel that holds the painting

public static void main(String[] args) 
{
    JFrame frame = new JFrame("Boats");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    BoatPanel bp = new BoatPanel(); //creates a new instance of the BoatPanel created below
    frame.add(bp);
    frame.setSize(800, 800);
    frame.setVisible(true);
    frame.setResizable(false); //prohibits resizing.
}
}

class BoatPanel extends JPanel implements MouseListener, MouseMotionListener, ActionListener //this class creates the painting, handles the mouseEvents and the Timer Events
{
    /*
      Boat 1 will be the gray boat. 
      Boat 2 will be the Dark Gray boat. 
      Boat 3 will be the Black Boat
    */
    
    private  double centerX = 400; //The center of the painting and the Frame in the X plane
    private  double centerY = 400; //The center of the painting and the Frame in the Y plane
    
    int[] sail1X = {0, 180, 360}; //Initial location of the X values of the sail of the first sail boat
    int[] sail1Y = {500, 20, 500}; //Initial location of the Y values of the sail of the first sail boat
    int[] boat1X = {-10, 10, 350, 370}; //Initial location of the X values of the bottom part of the first boat
    int[] boat1Y = {525, 625, 625, 525}; //Initial location of the Y values of the bottom part of the first boat
    int boatBeam1X = 180; //Initial location of the X value of the mast of the first sail boat
    int boatBeam1Y = 450; //Initial location of the Y value of the mast of the first sail boat
    
    int[] sail2X = {400, 550, 650}; //Initial location of the X values of the sail of the second sail boat
    int[] sail2Y = {515, 35, 515};  //Initial location of the Y values of the sail of the second sail boat
    int[] boat2X = {390, 410, 750, 760};  //Initial location of the X values of the bottom part of the second boat
    int[] boat2Y = {540, 600, 600, 540};  //Initial location of the Y values of the bottom part of the first boat
    int boatBeam2X = 510;  //Initial location of the X value of the mast of the second sail boat
    int boatBeam2Y = 490;  //Initial location of the Y value of the mast of the second sail boat
    
    int[] sail3X = {50, 230, 410};  //Initial location of the X values of the sail of the third sail boat
    int[] sail3Y = {550, 40, 550};  //Initial location of the Y values of the sail of the third sail boat
    int[] boat3X = {40, 60, 400, 420};  //Initial location of the X values of the bottom part of the third boat
    int[] boat3Y = {575, 675, 675, 575};  //Initial location of the Y values of the bottom part of the third boat
    int boatBeam3X = 230;  //Initial location of the X value of the mast of the third sail boat
    int boatBeam3Y = 490;  //Initial location of the Y value of the mast of the third sail boat
    
    /* The following code creates a copy of the starting positions indicated in upper chunk of code
       The copies are created in order to reset the boats back to their original position
       within the resetBoats() method. 
    */
    
    int[] sail1XCopy = {0, 180, 360}; //Initial location of the X values of the sail of the first sail boat
    int[] sail1YCopy = {500, 20, 500}; //Initial location of the Y values of the sail of the first sail boat
    int[] boat1XCopy = {-10, 10, 350, 370}; //Initial location of the X values of the bottom part of the first boat
    int[] boat1YCopy = {525, 625, 625, 525}; //Initial location of the Y values of the bottom part of the first boat
    int[] sail2XCopy = {400, 550, 650}; //Initial location of the X values of the sail of the second sail boat
    int[] sail2YCopy = {515, 35, 515};  //Initial location of the Y values of the sail of the second sail boat
    int[] boat2XCopy = {390, 410, 750, 760};  //Initial location of the X values of the bottom part of the second boat
    int[] boat2YCopy = {540, 600, 600, 540};  //Initial location of the Y values of the bottom part of the first boat
    int[] sail3XCopy = {50, 230, 410};  //Initial location of the X values of the sail of the third sail boat
    int[] sail3YCopy = {550, 40, 550};  //Initial location of the Y values of the sail of the third sail boat
    int[] boat3XCopy = {40, 60, 400, 420};  //Initial location of the X values of the bottom part of the third boat
    int[] boat3YCopy = {575, 675, 675, 575};  //Initial location of the Y values of the bottom part of the third boat
    
    int originalSkyX = 0; //The blue sky X value for blue rectangle
    int originalSkyY = 0; //The blue sky Y value for blue rectangle
    int originalSunX = 500; //The X value for the yellow sun
    int originalSunY = 50;  //The Y value for the yellow sun
    
    int sunSetOrangeX = 0; //Sets the X value for the orange rectangle used in drawing the sunset
    int sunSetOrangeY = 400;  //Sets the Y value for the orange rectangle used in drawing the sunset
    int sunSetRedX = 0;  //Sets the X value for the red rectangle used in drawing the sunset
    int sunSetRedY = 650;  //Sets the Y value for the red rectangle used in drawing the sunset
    int sunSetSunY = 750;  //sets the sun in the sunSet portion's Y value
    
    int starrySkyX = 0; //Sets the black rectangle used for the night sky location (x-value)
    int starrySkyY = 400; //Sets the black rectangle used for the nigth sky location (y-value)
    
    int shootingStarX = 900; //sets initial value for the shooting star (x-value)
    int shootingStarY = 100; //sets inital value for the shooting star (y-value)
    
    int numClicks = 1; //accumulates number of clicks to keep track if background is night or day.
    Timer tmr = new Timer(1, this); //creates a new timer used to move the shooting star.
    
    int currentX; //holds the current x value of when the mouse is pressed
    int currentY; //holds the current y value of when the mouse is pressed
    
public BoatPanel() //the constructor. This adds the mouseMotion and MouseListener capabilities to this class.
{
     addMouseMotionListener(this); 
     addMouseListener(this);
}
   
public void paintSail1(Graphics g, int[] xCords, int[] yCords) //Handles the painting of gray sail.
{
 g.setColor(Color.GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintSail2(Graphics g, int[] xCords, int[] yCords) //Handles the painting of the dark gray sail.
{
 g.setColor(Color.DARK_GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintSail3(Graphics g, int[] xCords, int[] yCords) //Handles the painting of the black sail
{
 g.setColor(Color.BLACK);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintWater(Graphics g) //Handles the painting of water
{
    g.setColor(Color.BLUE);
    g.fillRect(-10, 400, 900, 900);
}

public void paintBoat1(Graphics g, int[] xCords, int[] yCords) //Handles the painting of the base of the Gray boat.
{
    g.setColor(Color.GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat2(Graphics g, int[] xCords, int[] yCords) //Handles the painting of the base of the Dark Gray boat.
{
    g.setColor(Color.DARK_GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat3(Graphics g, int[] xCords, int[] yCords) //Handles the painting of the base of the Black boat.
{
    g.setColor(Color.BLACK);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoatBeam1(Graphics g, int x, int y) //Handles the painting of the beam of the Gray boat.
{
    g.setColor(Color.GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam2(Graphics g, int x, int y) //Handles the painting of the beam of the Dark Gray boat.
{
    g.setColor(Color.DARK_GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam3(Graphics g, int x, int y) //Handles the painting of the beam of the Black boat.
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintDefaultSky(Graphics g, int x, int y, int sunX, int sunY) //Handles the painting of the blue sky
{
    g.setColor(Color.CYAN);
    g.fillRect(x, y, 800, 800);
    g.setColor(Color.YELLOW);
    g.fillOval(sunX, sunY, 300, 300);
}

public void paintSunSet(Graphics g, int x1, int y1, int x2, int y2, int y3) //Handles the painting of the Draggable Sunset
{
    g.setColor(Color.ORANGE);
    g.fillRect(x1, y1, 800, 800);
    g.setColor(Color.RED);
    g.fillRect(x2, y2, 800, 800);
    g.setColor(Color.PINK);
    g.fillOval(300, y3, 200, 200);
}

public void paintStarrySky(Graphics g, int x, int y) //Handles the painting of the night sky
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 800, 800);
    
    if(numClicks % 2 == 0) //this code changes the color of the moon. If its night-time, it is white. If not, its Cyan to match the day sky
    {
        g.setColor(Color.WHITE);
    }
    else
    {
        g.setColor(Color.CYAN);
    }
    
    g.fillOval(300, 300, 200, 200);
}

public void paintShootingStar(Graphics g, int x, int y) //Handles the painting of the shooting star
{
    g.setColor(Color.YELLOW);
    g.fillOval(x, y, 20, 20);
}
    
public void paint(Graphics g) //This is the graphics method. It paints the picture based of constantly-updating parameters. All shapes have to be re-painted whenever the mouse moves.
{
    super.paint(g);
    paintDefaultSky(g, originalSkyX, originalSkyX, originalSunX, originalSunY);
    paintStarrySky(g, starrySkyX, starrySkyY);
    paintSunSet(g, sunSetOrangeX, sunSetOrangeY, sunSetRedX, sunSetRedY, sunSetSunY);
    paintShootingStar(g, shootingStarX, shootingStarY);
    paintWater(g);
    paintBoatBeam2(g, boatBeam2X, boatBeam2Y);
    paintSail2(g, sail2X, sail2Y);
    paintBoat2(g, boat2X, boat2Y);
    paintBoatBeam1(g, boatBeam1X, boatBeam1Y);
    paintSail1(g, sail1X, sail1Y);
    paintBoat1(g, boat1X, boat1Y);
    paintBoatBeam3(g, boatBeam3X, boatBeam3Y);
    paintSail3(g, sail3X, sail3Y);
    paintBoat3(g, boat3X, boat3Y);
}

private void resetBoats() //This function resets the position of the boats back to original places. Used if mouse leaves the canvas.
{
    boatBeam1X = 180; //Initial location of the X value of the mast of the first sail boat
    boatBeam1Y = 450; //Initial location of the Y value of the mast of the first sail boat
    boatBeam2X = 510;  //Initial location of the X value of the mast of the second sail boat
    boatBeam2Y = 490;  //Initial location of the Y value of the mast of the second sail boat
    boatBeam3X = 230;  //Initial location of the X value of the mast of the third sail boat
    boatBeam3Y = 490;  //Initial location of the Y value of the mast of the third sail boat
    
    sail1X = sail1XCopy.clone(); //sets the positions of all the boats to their original positions (the copies kept the starting positions saved)
    sail1Y = sail1YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat1X = boat1XCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat1Y = boat1YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    sail2X = sail2XCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    sail2Y = sail2YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat2X = boat2XCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat2Y = boat2YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    sail3X = sail3XCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    sail3Y = sail3YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat3X = boat3XCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
    boat3Y = boat3YCopy.clone(); // shifts the positions of all boats to their original positions (the copies kept the starting positions saved)
}

public void mousePressed(MouseEvent e) //used to save the locations of X and Y if the mouse is clicked. Used with mouseDragged()
{
        currentX  = e.getX();
        currentY = e.getY();
}
    
public void mouseReleased(MouseEvent e) //Not used. (As per email - If mouseDragged is used we dont have to use mousePressed or mouseReleased)
{
        
}
    
public void mouseClicked(MouseEvent e) //If mouseClicked is used, it paints a night sky to the screen.
{
    if(numClicks % 2 != 0) //detects if its night or day
    {
        starrySkyX = 0; //sets X and Y for the night sky to the origin of the screen
        starrySkyY = 0;
    }
    else //if its supposed to be daytime, the sky is moved beneath the ocean layer
    {
        starrySkyY = 400;
    }
    numClicks++; //increments numClicks
    repaint();
}
    
public void mouseEntered(MouseEvent e) //When the mouse enters the screen and its either nightTime or sunset, a shooting star will fire.
{
    if(numClicks % 2 == 0) //detects whether its nighttime or daytime.
    {
        tmr.start(); //stars the timer
        shootingStarX = 900; //sets the shootingStarX coordinate back to outside the right side of the screen.
    }
}
    
public void mouseExited(MouseEvent e) //When the mouse exits the screen, we reset the boat position to their original places AND put the mouse back to the center.
{
  resetBoats(); //resets boat positions
  repaint(); //refresh the screen
  int xCoord = 400; //the xMouse position
  int yCoord = 400; //the yMouse position
  try 
    {
        Robot robot = new Robot(); //new robot instance. Used to move the mouse back to the center of the screen
        if (e.getX() > 785 || e.getX() < 0 || e.getY() < - 40 || e.getY() > 800) 
        {
        robot.mouseMove(xCoord, yCoord); //mouse is moved to center of screen.
        }
    }
    catch(AWTException f)
    {
        
    }
}

public void mouseDragged(MouseEvent e) //When you click and drag, a sunset is drawn to the screen. The daytime sun goes up and down based on the direction you are dragging.
{
    if((currentY > (sunSetOrangeY - 40)) && (currentY < (sunSetOrangeY + 40))) //makes it so you need to be close to top of sunset before you can drag.
    {
        sunSetOrangeY = e.getY(); //changes the orangeY value of the sunset
        sunSetRedY = e.getY() + 250; //changes the redY value of the sunset
        sunSetSunY = e.getY() + 300; //changes the sun value of the sunset
        if(e.getY() < currentY) //lowers the day sun
        {
            originalSunY++; 
        }
        else if(e.getY() > currentY) //raises the day sun
        {
            originalSunY--;
        }
        currentY = e.getY();
        repaint();
    }
}
    
public void mouseMoved(MouseEvent e) //handles the movement of the ships. Gives the illusion of parallax mapping as mouse is moved across screen.
{
    int mouseX = e.getX();
    int XlimitRight = 500; //sets the limit of how far the mouse can move to the right
    int XlimitLeft = 300;  //sets the limit of how far the mouse can move to the left
    
    if(mouseX > centerX + 20) //if the mouse is greater than the x cordinate of the center of the screen, we move the boats right.
    {
        for(int i = 0; i < sail1X.length; i++) //moves the sails at different speeds
        {
            sail1X[i] += 2; // middle boat
            sail2X[i] += 1; // back boat
            sail3X[i] += 3; // front boat
        }
            
        for(int i = 0; i < boat3X.length; i++) //moves the base of the boats at different speeds
        {
            boat1X[i] += 2;
            boat2X[i] += 1;
            boat3X[i] += 3;
        }
            
        boatBeam1X += 2; //moves the boat beams
        boatBeam2X += 1;
        boatBeam3X += 3;
            
        if(mouseX > XlimitRight) //If the mouse is the the right of the right side limit, we make the center of the screen the X value of the limit
        {
            centerX = XlimitRight;
                
            if(mouseX < centerX) //If the mouseX value is left of the center (meaning the mouse moved back to the left of the new center), we move the boats left.
            {
                for(int z = 0; z < sail1X.length; z++) //moves the sails
                {
                    sail1X[z] -= 2;
                    sail2X[z] -= 1;
                    sail3X[z] -= 3;
                }
                    
                for(int z = 0; z < boat3X.length; z++) //moves the boats
                {
                    boat1X[z] -= 2;
                    boat2X[z] -= 1;
                    boat3X[z] -= 3;
                }
                    
                boatBeam1X -= 2; //moves the beams
                boatBeam2X -= 1;
                boatBeam3X -= 3;
            }
        }
    }
        
    if(mouseX < centerX - 20) //If teh mouseX value is left of the center, then we move boats to the left
    {
        for(int z = 0; z < sail1X.length; z++) //move sails to the left
        {
            sail1X[z] -= 2;
            sail2X[z] -= 1;
            sail3X[z] -= 3;
        }
            
        for(int z = 0; z < boat3X.length; z++) //move boats to the left
        {
            boat1X[z] -= 2;
            boat2X[z] -= 1;
            boat3X[z] -= 3;
        }
            
        boatBeam1X -= 2; //moves beams to the left
        boatBeam2X -= 1;
        boatBeam3X -= 3;
           
        if(mouseX < XlimitLeft) //resets the center of screen if the X mouse coordinate passes the left limit
        {
            centerX = XlimitLeft; //limit becomes the new center
                
            if(mouseX > centerX) //if the mouseX coordinate is to the right of the new center, we move the boats back to the right
            {
                for(int z = 0; z < sail1X.length; z++)
                {
                    sail1X[z] -= 2;
                    sail2X[z] -= 1;
                    sail3X[z] -= 3;
                }
                    
                for(int z = 0; z < boat3X.length; z++)
                {
                    boat1X[z] -= 2;
                    boat2X[z] -= 1;
                    boat3X[z] -= 3;
                }
                boatBeam1X -= 2;
                boatBeam2X -= 1;
                boatBeam3X -= 3;
            }
        }
            
    }
    repaint();
}

public void actionPerformed(ActionEvent e) //fires if the timer is activated
{
    shootingStarX--; //shooting star X value is updated and moves to the left
    
    if(shootingStarX < -50) //once the star gets across the screen, we stop the timer
        {
            tmr.stop();
        }
    
    repaint();
}
}