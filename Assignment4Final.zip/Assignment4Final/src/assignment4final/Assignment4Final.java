/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4final;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.util.Random;





public class Assignment4Final {

    
public static void main(String[] args) {
    
    JFrame frame = new JFrame("Boats");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    BoatPanel bp = new BoatPanel();
    frame.add(bp);

    frame.setSize(800, 800);
    frame.setVisible(true);
    frame.setResizable(false);

    }
    
}

class BoatPanel extends JPanel implements MouseListener, MouseMotionListener, ActionListener
{
    
    private  double centerX = 400;
    private  double centerY = 400;
    
    private double layer1DX = 1; //these control the layer that is furthest in background
    private double layer1DY = 1;
    
    int[] mountain1X = {0, 180, 360};
    int[] mountain1Y = {500, 20, 500};
    
    int[] boat1X = {-10, 10, 350, 370}; 
    int[] boat1Y = {525, 625, 625, 525};
    
    int boatBeam1X = 180;
    int boatBeam1Y = 450;
    
    int[] mountain2X = {400, 550, 650};
    int[] mountain2Y = {515, 35, 515};
    
    int[] boat2X = {390, 410, 750, 760};
    int[] boat2Y = {540, 600, 600, 540};
    
    int boatBeam2X = 510;
    int boatBeam2Y = 490;
    
    int[] mountain3X = {50, 230, 410};
    int[] mountain3Y = {550, 40, 550};
    
    int[] boat3X = {40, 60, 400, 420};
    int[] boat3Y = {575, 675, 675, 575};
    
    int boatBeam3X = 230;
    int boatBeam3Y = 490;
    
    int originalSkyX = 0;
    int originalSkyY = 0;
    int originalSunX = 500;
    int originalSunY = 50;
    
    int sunSetOrangeX = 0;
    int sunSetOrangeY = 400;
    int sunSetRedX = 0;
    int sunSetRedY = 650;
    


    int starX;
    int starY;
    int starrySkyX = 0;
    int starrySkyY = 400;
    
    int shootingStarX = 900;
    int shootingStarY = 100;
    
    int numClicks = 1; //accumulates number of clicks
    Timer tmr = new Timer(1, this);
    
    
    int currentX;
    int currentY;
    
public BoatPanel()
{
     addMouseMotionListener(this);
     addMouseListener(this);
     
     
}
    

    
public void paintMountain1(Graphics g, int[] xCords, int[] yCords) //
{
 //getContentPane().setBackground(Color.white);
 g.setColor(Color.GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintMountain2(Graphics g, int[] xCords, int[] yCords)
{
 g.setColor(Color.DARK_GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintMountain3(Graphics g, int[] xCords, int[] yCords)
{
 g.setColor(Color.BLACK);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintWater(Graphics g)
{
    g.setColor(Color.BLUE);
    g.fillRect(-10, 400, 900, 900);
}

public void paintBoat3(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.BLACK);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat1(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat2(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.DARK_GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoatBeam1(Graphics g, int x, int y)
{
    g.setColor(Color.GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam2(Graphics g, int x, int y)
{
    g.setColor(Color.DARK_GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam3(Graphics g, int x, int y)
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintDefaultSky(Graphics g, int x, int y, int sunX, int sunY)
{
    g.setColor(Color.CYAN);
    g.fillRect(x, y, 800, 800);
    g.setColor(Color.YELLOW);
    g.fillOval(sunX, sunY, 300, 300);
}

public void paintSunSet(Graphics g, int x1, int y1, int x2, int y2)
{
    g.setColor(Color.ORANGE);
    g.fillRect(x1, y1, 800, 800);
    g.setColor(Color.RED);
    g.fillRect(x2, y2, 800, 800);
}

public void paintStarrySky(Graphics g, int x, int y)
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 800, 800);
    
    if(numClicks % 2 == 0)
    {
        g.setColor(Color.WHITE);
    }
    else
    {
        g.setColor(Color.CYAN);
    }
    
    g.fillOval(300, 300, 200, 200);
}

public void paintShootingStar(Graphics g, int x, int y)
{
    g.setColor(Color.MAGENTA);
    g.fillOval(x, y, 20, 20);
    
}
    
    
public void paint(Graphics g)
{
 super.paint(g);
 paintDefaultSky(g, originalSkyX, originalSkyX, originalSunX, originalSunY);
 paintStarrySky(g, starrySkyX, starrySkyY);
 paintSunSet(g, sunSetOrangeX, sunSetOrangeY, sunSetRedX, sunSetRedY);
 paintShootingStar(g, shootingStarX, shootingStarY);
 paintWater(g);
 paintBoatBeam2(g, boatBeam2X, boatBeam2Y);
 paintMountain2(g, mountain2X, mountain2Y);
 paintBoat2(g, boat2X, boat2Y);
 paintBoatBeam1(g, boatBeam1X, boatBeam1Y);
 paintMountain1(g, mountain1X, mountain1Y);
 paintBoat1(g, boat1X, boat1Y);
 paintBoatBeam3(g, boatBeam3X, boatBeam3Y);
 paintMountain3(g, mountain3X, mountain3Y);
 paintBoat3(g, boat3X, boat3Y);
}

public void mousePressed(MouseEvent e)
{
        currentX  = e.getX();
        currentY = e.getY();
        
        

        
}
    
public void mouseReleased(MouseEvent e)
{
        
}
    
public void mouseClicked(MouseEvent e)
{
    if(numClicks % 2 != 0)
    {
        starrySkyX = 0;
        starrySkyY = 0;
    }
    else
    {
        starrySkyY = 400;
    }

    numClicks++;
    repaint();
}
    
public void mouseEntered(MouseEvent e)
{
        if(numClicks % 2 == 0)
        {
            tmr.start();
            shootingStarX = 900;
            //shootingStarY = 100;
        }
}
    
public void mouseExited(MouseEvent e)
{
        
}

public void actionPerformed(ActionEvent e)
{
    shootingStarX--;
    //shootingStarY--;
    if(shootingStarX < -50)
    {
        tmr.stop();
        
    }
    repaint();
    
}



public void mouseDragged(MouseEvent e) //When you click and drag, a sunset is drawn to the screen
{
    
    
    if((currentY > (sunSetOrangeY - 40)) && (currentY < (sunSetOrangeY + 40)))
    {
        System.out.println("Hello");
        sunSetOrangeY = e.getY();
        sunSetRedY = e.getY() + 250;
        if(e.getY() < currentY)
        {
            originalSunY++;
        }
        else if(e.getY() > currentY)
        {
            originalSunY--;
        }
        currentY = e.getY();
        
        repaint();
    }

        
        
        
        
        
}
    
public void mouseMoved(MouseEvent e)
{
    
    int mouseX = e.getX();
    int mouseY = e.getY();
    int XlimitRight = 500;
    int XlimitLeft = 300;
        
    int YlimitTop = 200;
    int YlimitBottom = 600;
        

        
    if(mouseX > centerX + 20)
    {
            //layer1DX = mouseX - centerX;
        for(int i = 0; i < mountain1X.length; i++)
        {
            mountain1X[i] += 1;
            mountain2X[i] += 2;
            mountain3X[i] += 3;
        }
            
        for(int i = 0; i < boat3X.length; i++)
        {
            boat1X[i] += 1;
            boat2X[i] += 2;
            boat3X[i] += 3;
        }
            
        boatBeam1X +=1;
        boatBeam2X +=2;
        boatBeam3X +=3;
            
        if(mouseX > XlimitRight)
        {
            centerX = XlimitRight;
                
            if(mouseX < centerX)
            {
                for(int z = 0; z < mountain1X.length; z++)
                {
                    mountain1X[z] -= 1;
                    mountain2X[z] -= 2;
                    mountain3X[z] -= 3;
                }
                    
                for(int z = 0; z < boat3X.length; z++)
                {
                    boat1X[z] -=1;
                    boat2X[z] -= 2;
                        
                    boat3X[z] -=3;
                }
                    
                boatBeam1X -=1;
                boatBeam2X -=2;
                boatBeam3X -=3;
            }
                
                
        }
    }
        
    if(mouseX < centerX - 20)
    {
        for(int z = 0; z < mountain1X.length; z++)
        {
            mountain1X[z] -= 1;
            mountain2X[z] -= 2;
            mountain3X[z] -= 3;
                
                
        }
            
        for(int z = 0; z< boat3X.length; z++)
        {
            boat1X[z] -=1;
            boat2X[z] -=2;
            boat3X[z] -=3;
        }
            
        boatBeam1X -=1;
        boatBeam2X -=2;
        boatBeam3X -=3;
            
        if(mouseX < XlimitLeft)
        {
            centerX = XlimitLeft;
                
            if(mouseX > centerX )
            {
                for(int z = 0; z < mountain1X.length; z++)
                {
                    mountain1X[z] -= 1;
                    mountain2X[z] -= 2;
                    mountain3X[z] -= 3;
                        
                        
                }
                    
                for(int z = 0; z < boat3X.length; z++)
                {
                    boat1X[z] -=1;
                    boat2X[z] -=2;
                    boat3X[z] -=3;
                }
                boatBeam1X -=1;
                boatBeam2X -=2;
                boatBeam3X -=3;
            }
        }
            
    }
    repaint();
}
}
