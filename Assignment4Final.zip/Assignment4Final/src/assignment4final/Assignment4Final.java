/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment4final;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.util.Random;


public class Assignment4Final {  //This class handles the creation of the JFrame and the JPanel that holds the painting

    
public static void main(String[] args) {
    
    JFrame frame = new JFrame("Boats");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    BoatPanel bp = new BoatPanel(); //creates a new instance of the BoatPanel created below
    frame.add(bp);
    frame.setSize(800, 800);
    frame.setVisible(true);
    frame.setResizable(false); //prohibits resizing.

    }
    
}

class BoatPanel extends JPanel implements MouseListener, MouseMotionListener, ActionListener //this class creates the painting, handles the mouseEvents and the Timer Events
{
    
    private  double centerX = 400; //The center of the painting and the Frame in the X plane
    private  double centerY = 400; //The center of the painting and the Frame in the Y plane
    

    
    int[] sail1X = {0, 180, 360}; //Initial location of the X values of the sail of the first sail boat
    int[] sail1Y = {500, 20, 500}; //Initial location of the Y values of the sail of the first sail boat
    int[] boat1X = {-10, 10, 350, 370}; //Initial location of the X values of the bottom part of the first boat
    int[] boat1Y = {525, 625, 625, 525}; //Initial location of the Y values of the bottom part of the first boat
    int boatBeam1X = 180; //Initial location of the X value of the mast of the first sail boat
    int boatBeam1Y = 450; //Initial location of the Y value of the mast of the first sail boat
    
    int[] sail2X = {400, 550, 650}; //Initial location of the X values of the sail of the second sail boat
    int[] sail2Y = {515, 35, 515};  //Initial location of the Y values of the sail of the second sail boat
    int[] boat2X = {390, 410, 750, 760};  //Initial location of the X values of the bottom part of the second boat
    int[] boat2Y = {540, 600, 600, 540};  //Initial location of the Y values of the bottom part of the first boat
    int boatBeam2X = 510;  //Initial location of the X value of the mast of the second sail boat
    int boatBeam2Y = 490;  //Initial location of the Y value of the mast of the second sail boat
    
    int[] sail3X = {50, 230, 410};  //Initial location of the X values of the sail of the third sail boat
    int[] sail3Y = {550, 40, 550};  //Initial location of the Y values of the sail of the third sail boat
    int[] boat3X = {40, 60, 400, 420};  //Initial location of the X values of the bottom part of the third boat
    int[] boat3Y = {575, 675, 675, 575};  //Initial location of the Y values of the bottom part of the third boat
    int boatBeam3X = 230;  //Initial location of the X value of the mast of the third sail boat
    int boatBeam3Y = 490;  //Initial location of the Y value of the mast of the third sail boat
    
    int originalSkyX = 0; //The blue sky X value for blue rectangle
    int originalSkyY = 0; //The blue sky Y value for blue rectangle
    int originalSunX = 500; //The X value for the yellow sun
    int originalSunY = 50;  //The Y value for the yellow sun
    
    int sunSetOrangeX = 0; //Sets the X value for the orange rectangle used in drawing the sunset
    int sunSetOrangeY = 400;  //Sets the Y value for the orange rectangle used in drawing the sunset
    int sunSetRedX = 0;  //Sets the X value for the red rectangle used in drawing the sunset
    int sunSetRedY = 650;  //Sets the Y value for the red rectangle used in drawing the sunset
    int sunSetSunY = 750;  //sets the sun in the sunSet portion's Y value
    
    int starrySkyX = 0; //Sets the black rectangle used for the night sky location (x-value)
    int starrySkyY = 400; //Sets the black rectangle used for the nigth sky location (y-value)
    
    int shootingStarX = 900; //sets initial value for the shooting star (x-value)
    int shootingStarY = 100; //sets inital value for the shooting star (y-value)
    
    int numClicks = 1; //accumulates number of clicks to keep track if background is night or day.
    Timer tmr = new Timer(1, this); //creates a new timer used to move the shooting star.
    
    int currentX; //holds the current x value of when the mouse is pressed
    int currentY; //holds the current y value of when the mouse is pressed
    
public BoatPanel() //the constructor. This adds the mouseMotion and MouseListener capabilities to this class.
{
     addMouseMotionListener(this);
     addMouseListener(this);
}
   
public void paintMountain1(Graphics g, int[] xCords, int[] yCords) //
{
 
 g.setColor(Color.GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintMountain2(Graphics g, int[] xCords, int[] yCords)
{
 g.setColor(Color.DARK_GRAY);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintMountain3(Graphics g, int[] xCords, int[] yCords)
{
 g.setColor(Color.BLACK);
 g.fillPolygon(xCords, yCords, 3);
}

public void paintWater(Graphics g)
{
    g.setColor(Color.BLUE);
    g.fillRect(-10, 400, 900, 900);
}

public void paintBoat3(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.BLACK);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat1(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoat2(Graphics g, int[] xCords, int[] yCords)
{
    g.setColor(Color.DARK_GRAY);
    g.fillPolygon(xCords, yCords, 4);
}

public void paintBoatBeam1(Graphics g, int x, int y)
{
    g.setColor(Color.GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam2(Graphics g, int x, int y)
{
    g.setColor(Color.DARK_GRAY);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintBoatBeam3(Graphics g, int x, int y)
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 20, 100); //creates beam with 20 width, 40 height
}

public void paintDefaultSky(Graphics g, int x, int y, int sunX, int sunY)
{
    g.setColor(Color.CYAN);
    g.fillRect(x, y, 800, 800);
    g.setColor(Color.YELLOW);
    g.fillOval(sunX, sunY, 300, 300);
}

public void paintSunSet(Graphics g, int x1, int y1, int x2, int y2, int y3)
{
    g.setColor(Color.ORANGE);
    g.fillRect(x1, y1, 800, 800);
    g.setColor(Color.RED);
    g.fillRect(x2, y2, 800, 800);
    g.setColor(Color.PINK);
    g.fillOval(300, y3, 200, 200);
}

public void paintStarrySky(Graphics g, int x, int y)
{
    g.setColor(Color.BLACK);
    g.fillRect(x, y, 800, 800);
    
    if(numClicks % 2 == 0)
    {
        g.setColor(Color.WHITE);
    }
    else
    {
        g.setColor(Color.CYAN);
    }
    
    g.fillOval(300, 300, 200, 200);
}

public void paintShootingStar(Graphics g, int x, int y)
{
    g.setColor(Color.MAGENTA);
    g.fillOval(x, y, 20, 20);
    
}
    
    
public void paint(Graphics g)
{
 super.paint(g);
 paintDefaultSky(g, originalSkyX, originalSkyX, originalSunX, originalSunY);
 paintStarrySky(g, starrySkyX, starrySkyY);
 paintSunSet(g, sunSetOrangeX, sunSetOrangeY, sunSetRedX, sunSetRedY, sunSetSunY);
 paintShootingStar(g, shootingStarX, shootingStarY);
 paintWater(g);
 paintBoatBeam2(g, boatBeam2X, boatBeam2Y);
 paintMountain2(g, sail2X, sail2Y);
 paintBoat2(g, boat2X, boat2Y);
 paintBoatBeam1(g, boatBeam1X, boatBeam1Y);
 paintMountain1(g, sail1X, sail1Y);
 paintBoat1(g, boat1X, boat1Y);
 paintBoatBeam3(g, boatBeam3X, boatBeam3Y);
 paintMountain3(g, sail3X, sail3Y);
 paintBoat3(g, boat3X, boat3Y);
}

public void mousePressed(MouseEvent e)
{
        currentX  = e.getX();
        currentY = e.getY();
        
        

        
}
    
public void mouseReleased(MouseEvent e)
{
        
}
    
public void mouseClicked(MouseEvent e)
{
    if(numClicks % 2 != 0)
    {
        starrySkyX = 0;
        starrySkyY = 0;
    }
    else
    {
        starrySkyY = 400;
    }

    numClicks++;
    repaint();
}
    
public void mouseEntered(MouseEvent e)
{
        if(numClicks % 2 == 0)
        {
            tmr.start();
            shootingStarX = 900;
            //shootingStarY = 100;
        }
}
    
public void mouseExited(MouseEvent e)
{
        
}

public void actionPerformed(ActionEvent e)
{
    shootingStarX--;
    //shootingStarY--;
    if(shootingStarX < -50)
    {
        tmr.stop();
        
    }
    repaint();
    
}



public void mouseDragged(MouseEvent e) //When you click and drag, a sunset is drawn to the screen
{
    
    
    if((currentY > (sunSetOrangeY - 40)) && (currentY < (sunSetOrangeY + 40)))
    {
        System.out.println("Hello");
        sunSetOrangeY = e.getY();
        sunSetRedY = e.getY() + 250;
        sunSetSunY = e.getY() + 300;
        if(e.getY() < currentY)
        {
            originalSunY++;
        }
        else if(e.getY() > currentY)
        {
            originalSunY--;
        }
        currentY = e.getY();
        
        repaint();
    }

        
        
        
        
        
}
    
public void mouseMoved(MouseEvent e)
{
    
    int mouseX = e.getX();
    int mouseY = e.getY();
    int XlimitRight = 500;
    int XlimitLeft = 300;
        
    int YlimitTop = 200;
    int YlimitBottom = 600;
        

        
    if(mouseX > centerX + 20)
    {
            //layer1DX = mouseX - centerX;
        for(int i = 0; i < sail1X.length; i++)
        {
            sail1X[i] += 1;
            sail2X[i] += 2;
            sail3X[i] += 3;
        }
            
        for(int i = 0; i < boat3X.length; i++)
        {
            boat1X[i] += 1;
            boat2X[i] += 2;
            boat3X[i] += 3;
        }
            
        boatBeam1X +=1;
        boatBeam2X +=2;
        boatBeam3X +=3;
            
        if(mouseX > XlimitRight)
        {
            centerX = XlimitRight;
                
            if(mouseX < centerX)
            {
                for(int z = 0; z < sail1X.length; z++)
                {
                    sail1X[z] -= 1;
                    sail2X[z] -= 2;
                    sail3X[z] -= 3;
                }
                    
                for(int z = 0; z < boat3X.length; z++)
                {
                    boat1X[z] -=1;
                    boat2X[z] -= 2;
                        
                    boat3X[z] -=3;
                }
                    
                boatBeam1X -=1;
                boatBeam2X -=2;
                boatBeam3X -=3;
            }
                
                
        }
    }
        
    if(mouseX < centerX - 20)
    {
        for(int z = 0; z < sail1X.length; z++)
        {
            sail1X[z] -= 1;
            sail2X[z] -= 2;
            sail3X[z] -= 3;
                
                
        }
            
        for(int z = 0; z< boat3X.length; z++)
        {
            boat1X[z] -=1;
            boat2X[z] -=2;
            boat3X[z] -=3;
        }
            
        boatBeam1X -=1;
        boatBeam2X -=2;
        boatBeam3X -=3;
            
        if(mouseX < XlimitLeft)
        {
            centerX = XlimitLeft;
                
            if(mouseX > centerX )
            {
                for(int z = 0; z < sail1X.length; z++)
                {
                    sail1X[z] -= 1;
                    sail2X[z] -= 2;
                    sail3X[z] -= 3;
                        
                        
                }
                    
                for(int z = 0; z < boat3X.length; z++)
                {
                    boat1X[z] -=1;
                    boat2X[z] -=2;
                    boat3X[z] -=3;
                }
                boatBeam1X -=1;
                boatBeam2X -=2;
                boatBeam3X -=3;
            }
        }
            
    }
    repaint();
}
}
