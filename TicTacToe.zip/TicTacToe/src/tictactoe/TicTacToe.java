/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
    NAMES: DONOVAN FARAR & ANTHONY KASKURS
    DUE DATE: 02/24/2019
    ASSIGNMENT: ASSIGNMENT 3 - TICTACTOE
 */
package tictactoe;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
/**
 *
 * @author AK 47
 */
public class TicTacToe extends JFrame{
    
    private int userTurn = 0; //if the number is even, then its player one's turn and we place an X. Else we place an O.
    private int winCounter1 = 0; //integer value that holds the amount of player one wins
    private int winCounter2 = 0; //integer value that holds the amount of player two wins
    private int lossCounter1 = 0; //holds losses p2
    private int lossCounter2 = 0; //holds losses p2
    
    ImageIcon mario = new ImageIcon("totoro.jpg"); //images to be used as buttons
    ImageIcon luigi = new ImageIcon("spiderman.gif");
    
    private final int WINDOW_WIDTH = 500; //sets the window width to 500 
    private final int WINDOW_HEIGHT = 500; //sets the window height to 500
    private String enteredNamePlayerOne; //holds the string value that player one enters into the textField
    private String enteredNamePlayerTwo; //holds player 2's name
    
    private JPanel error; 
    private JPanel playerOneInfoPanel; //To hold the things inside the player one information panel (scores, names etc)
    private JTextField playerOneName; //the textfield where player one inputs their name
    private JLabel name1; //the label that holds the "name :" text
    private JLabel wins1; //the label that holds the "wins: " text
    private JLabel losses1; //the label that holds the "losses: " text
    private JLabel winsCount1; //the label that holds the counter variable winCounter1
    private JLabel lossCount1; //the label that holds the counter variable lossCounter 1
    
    private JPanel playerTwoInfoPanel; //creates the player two information panel, similar to the code commented above
    private JTextField playerTwoName; 
    private JLabel name2;
    private JLabel wins2;
    private JLabel losses2;
    private JLabel winsCount2;
    private JLabel lossCount2;
    
    private JPanel bothPlayerPanels; //the panel that holds both player's information and placed at the top
    
    private JPanel gameGrid; //creates the grid and the 9 buttons used in tic tac toe game
    private JButton topLeft; //upperleft button
    private JButton topMid; //etc...
    private JButton topRight;
    private JButton midLeft;
    private JButton midMid;
    private JButton midRight;
    private JButton botLeft;
    private JButton botMid;
    private JButton botRight;
    
    private JPanel lowerPanel;  //this lowerPanel is used for the text on the bottom of the screen and for the buttons the user can select
    private JPanel upperLowerPanel; //this panel has the three buttons in it
    private JButton newGameButton; //newgame button
    private JButton resetButton; //reset button
    private JButton exitButton; //exit button
    private JLabel bottomMessage; //this label is the message that appears at the bottom of the screen
    
    //this constuctor creates the GUI interface.
    public TicTacToe()
    {
        setTitle("Tic Tac Toe"); //sets title
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT); //sets size of window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout()); //uses a border layout
        
        buildPlayerInfo(); //builds the upper player informational panels
        buildTicTacToeGrid(); //builds the central tictactoegrid
        buildLowerArea(); //builds the bottom area of the frame that includes the buttons and the updating text
        
        add(bothPlayerPanels, BorderLayout.NORTH); //adds the created panels
        add(gameGrid, BorderLayout.CENTER);
        add(lowerPanel, BorderLayout.SOUTH);
        //pack();
        setVisible(true);
    }
    
    
    //builds the player information panels using a gird layout
    private void buildPlayerInfo()
    {
        bothPlayerPanels = new JPanel();
        bothPlayerPanels.setLayout(new GridLayout(1, 2)); //creates grid layout for player panels
        
        //player 1 panel 
        playerOneInfoPanel = new JPanel();
        playerOneName = new JTextField(8); //sets the text field to size 8, per instructions
        name1 = new JLabel("Name: ");
        wins1 = new JLabel("Wins: ");
        losses1 = new JLabel("Losses: ");
        winsCount1 = new JLabel(Integer.toString(winCounter1)); //sets the win/loss JLabels to the integer value of variable that counts wins
        lossCount1 = new JLabel(Integer.toString(lossCounter1));
        
        //player 2 panel 
        playerTwoInfoPanel = new JPanel();
        playerTwoName = new JTextField(8);
        name2 = new JLabel("Name: ");
        wins2 = new JLabel("Wins: ");
        losses2 = new JLabel("Losses: ");
        winsCount2 = new JLabel(Integer.toString(winCounter2)); 
        lossCount2 = new JLabel(Integer.toString(lossCounter2));
        
        playerOneInfoPanel.setLayout(new GridLayout(3, 3)); //makes each panel a 3 by 3 grid layout
        playerTwoInfoPanel.setLayout(new GridLayout(3, 3));
        
        //add all the labels and fields to the playerOneInfoPanel
        playerOneInfoPanel.setBorder(BorderFactory.createTitledBorder("Player 1 (totoro)")); //creates border
        playerOneInfoPanel.add(name1); 
        playerOneInfoPanel.add(playerOneName);
        playerOneInfoPanel.add(wins1);
        playerOneInfoPanel.add(winsCount1);
        playerOneInfoPanel.add(losses1);
        playerOneInfoPanel.add(lossCount1);
        
        //add all the labels and fields to the playerTwoInfoPanel
        playerTwoInfoPanel.setBorder(BorderFactory.createTitledBorder("Player 2 (spiderman)"));
        playerTwoInfoPanel.add(name2);
        playerTwoInfoPanel.add(playerTwoName);
        playerTwoInfoPanel.add(wins2);
        playerTwoInfoPanel.add(winsCount2);
        playerTwoInfoPanel.add(losses2);
        playerTwoInfoPanel.add(lossCount2);
        
        
        bothPlayerPanels.add(playerOneInfoPanel); //adds panel to left grid of bothPlayerPanels
        bothPlayerPanels.add(playerTwoInfoPanel); //adds panel to right grid of bothPlayerPanels
        
        
    }

    //builds the central tic tac toe grid itself
    private void buildTicTacToeGrid()
    {
        Font font = new Font("Arial", Font.BOLD, 0); //sets the font to 0. The reason for this is that we want to still use the Xs and Os when testing whether a game has been won, but we dont want them visible to the user 
        gameGrid = new JPanel();
        gameGrid.setLayout(new GridLayout(3, 3)); //creates grid layout
        
        topLeft = new JButton(""); //initializes each individual button. They need to be different or else game will end after the first turn
        topMid = new JButton(" ");
        topRight = new JButton("  ");
        midLeft = new JButton("   ");
        midMid = new JButton("    ");
        midRight = new JButton("     ");
        botLeft = new JButton("      ");
        botMid = new JButton("        ");
        botRight = new JButton("       ");
        
        topLeft.setEnabled(false); //disable all buttons on startup
        topMid.setEnabled(false);
        topRight.setEnabled(false);
        midLeft.setEnabled(false);
        midMid.setEnabled(false);
        midRight.setEnabled(false);
        botLeft.setEnabled(false);
        botMid.setEnabled(false);
        botRight.setEnabled(false);
        
        topLeft.setFont(font); //set the buttons font to 24 bold arial font
        topMid.setFont(font);
        topRight.setFont(font);
        midLeft.setFont(font);
        midMid.setFont(font);
        midRight.setFont(font);
        botLeft.setFont(font);
        botMid.setFont(font);
        botRight.setFont(font);
        
        topLeft.addActionListener(new TicTacToeButtonListener()); //add each button to action listener class
        topMid.addActionListener(new TicTacToeButtonListener());
        topRight.addActionListener(new TicTacToeButtonListener());
        midLeft.addActionListener(new TicTacToeButtonListener());
        midMid.addActionListener(new TicTacToeButtonListener());
        midRight.addActionListener(new TicTacToeButtonListener());
        botLeft.addActionListener(new TicTacToeButtonListener());
        botMid.addActionListener(new TicTacToeButtonListener());
        botRight.addActionListener(new TicTacToeButtonListener());
        
        gameGrid.add(topLeft); //add the buttons to the grid one by one
        gameGrid.add(topMid);
        gameGrid.add(topRight);
        gameGrid.add(midLeft);
        gameGrid.add(midMid);
        gameGrid.add(midRight);
        gameGrid.add(botLeft);
        gameGrid.add(botMid);
        gameGrid.add(botRight);
    }
    
    //builds the lower panel area that displays the three selection buttons and the bottom message
    private void buildLowerArea()
    {
       lowerPanel = new JPanel();
       upperLowerPanel = new JPanel();
       upperLowerPanel.setLayout(new GridLayout(1, 3)); //sets the upperLowerPanel (which has the new game, reset and exit bttns) to a 1 x 3
       lowerPanel.setLayout(new GridLayout(2, 1)); //sets the lower panel to a 2 by 1 layout (button panel on top, message on bottom)
       newGameButton = new JButton("New Game"); //initialize words in buttons
       resetButton = new JButton("Reset Game");
       exitButton = new JButton("Exit Game");
       bottomMessage = new JLabel("Welcome to Tic-Tac-Toe!");
       bottomMessage.setBorder(BorderFactory.createEtchedBorder());
       
       newGameButton.addActionListener(new gameStartExitResetListener()); //adds buttons to gameStarExitReset
       resetButton.addActionListener(new gameStartExitResetListener());
       exitButton.addActionListener(new gameStartExitResetListener());
       
       upperLowerPanel.add(newGameButton); //ads the buttons to the upper lower pannel in grid form
       upperLowerPanel.add(resetButton);
       upperLowerPanel.add(exitButton);
       
       lowerPanel.add(upperLowerPanel);//adds the upperLowerPanel to the grid (so its on top of message)
       lowerPanel.add(bottomMessage); //adds the bottomMessage panel to the grid second, so the message is on the bottom
    }
    
    
    //this class implements ActionListener, and deals with the logic of the TicTacToe game.
    private class TicTacToeButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            JButton buttonClicked; //creates a JButton 
            buttonClicked = (JButton)e.getSource(); //get the button that was clicked and have buttonClicked point to it so we can access the button that was pressed easily
            if((userTurn % 2 == 0) && (buttonClicked.getText() != "X") && (buttonClicked.getText() != "O")) //checks to see if its X's turn
            {
                bottomMessage.setText(enteredNamePlayerTwo + "'s turn"); //signifying player 1's turn is over
                buttonClicked.setIcon(mario); //button is changed to an image
                buttonClicked.setText("X");
                userTurn++; //increment the userTurn counter
                pack(); //we pack here to ensure that buttons are sized to the appropriate size to be able to see the button images.
            }
            else if((userTurn % 2 != 0) && (buttonClicked.getText() != "X") && (buttonClicked.getText() != "O"))
            {
                
                bottomMessage.setText(enteredNamePlayerOne + "'s turn"); //signifying player 2's turn is over
                buttonClicked.setIcon(luigi); //button is changed to an image
                buttonClicked.setText("O");
                userTurn++;
            }
            
            
            
            if(isWon()) //if the game is won by someone, the following occurs
            {
                newGameButton.setEnabled(true); //we re-enable the newGameButton
                if(userTurn % 2 != 0) //this means player 1 has won
                {
                    winCounter1++; //counts a win for player 1
                    lossCounter2++; //counts a loss for player 2
                    winsCount1.setText(Integer.toString(winCounter1)); //sets win count to JLabel 
                    lossCount2.setText(Integer.toString(lossCounter2));
                    
                }
                else if(userTurn % 2 == 0) //this means player 2 has won
                {
                    winCounter2++;
                    lossCounter1++;
                    winsCount2.setText(Integer.toString(winCounter2));
                    lossCount1.setText(Integer.toString(lossCounter1));
                }
                
                resetButtons(); //resets all the buttons on the board
                userTurn = 0;
            }
            
            else if(userTurn == 9 && !isWon()) //checks to see if board is filled and nobody is won
            {
                newGameButton.setEnabled(true);
                resetButtons(); //resets button if nobody wins as well, doesnt add win or loss.
                userTurn = 0; //resets userTurn
            }
            
            //pack();
        }
    }
    
    private class gameStartExitResetListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            enteredNamePlayerOne = playerOneName.getText(); //whatver has been entered into TextField is saved as name.
            enteredNamePlayerTwo = playerTwoName.getText();
            boolean wasError = false; 
            wasError = ErrorMessage(enteredNamePlayerOne, enteredNamePlayerTwo); //checks to see whether there was an error in the names by calling ErrorMessage()
            if (wasError && e.getSource() == newGameButton) //if there was an error and the user clicks the new game button, it will throw the output message
            {
                JOptionPane.showMessageDialog(error, "The name or names for this game are ILLEGAL. Please change them so that they are not empty and do not exclusively contain spaces.", "ERROR",  JOptionPane.ERROR_MESSAGE);
            }
            if(e.getSource() == newGameButton && !wasError) //if there was no error and the user clicks the new game button, we enable the buttons and start the game
            {
                topLeft.setEnabled(true); //sets buttons to editable
                topMid.setEnabled(true);
                topRight.setEnabled(true);
                midLeft.setEnabled(true);
                midMid.setEnabled(true);
                midRight.setEnabled(true);
                botLeft.setEnabled(true);
                botMid.setEnabled(true);
                botRight.setEnabled(true);
                
                playerOneName.setEditable(false); //makes the names uneditable
                playerTwoName.setEditable(false); //makes the names uneditable once game has started
                
                bottomMessage.setText(enteredNamePlayerOne + "'s Turn");
                newGameButton.setEnabled(false);
            }
            
            else if(e.getSource() == resetButton && !wasError) //if the user hits the resetButton and there is no error, then an output warning is given to user, as per instructions
            {
                JFrame resetDialog = new JFrame(); 
                String message = "This will end the game and set the win/loss stats to 0. Are you sure?";
                int answer = JOptionPane.showConfirmDialog(resetDialog, message, "option", JOptionPane.YES_NO_OPTION);
                if(answer == JOptionPane.YES_OPTION) //user clicks yes
                {
                    resetButtons(); //resets board to original state
                    resetStats(); //resets stats to original state
                    newGameButton.setEnabled(true);
                }
                
            }
            
            else if(e.getSource() == resetButton && wasError) //if the user hits the reset button and there was an error in names, we decided to also push an error message
            {
                JOptionPane.showMessageDialog(error, "Please ensure names have been entered into the text field before resetting stats", "ERROR",  JOptionPane.ERROR_MESSAGE);  
            }
            
            else if(e.getSource() == exitButton) //exits program
            {
                System.exit(0);
            }
        }
    }
    
    
    public boolean isWon() //checks to see whether there is a victory, returns true if so, false if not
    {
        if(topLeft.getText() == topMid.getText() && topLeft.getText() == topRight.getText())
        {
            return true;
        }
        else if(midLeft.getText() == midMid.getText() && midLeft.getText() == midRight.getText())
        {
            return true;
        }
        else if(botLeft.getText() == botMid.getText() && botLeft.getText() == botRight.getText())
        {
            return true;
        }
        else if(topLeft.getText() == midLeft.getText() && topLeft.getText() == botLeft.getText())
        {
            return true;
        }
        else if(topMid.getText() == midMid.getText() && topMid.getText() == botMid.getText())
        {
            return true;
        }
        else if(topRight.getText() == midRight.getText() && topRight.getText() == botRight.getText())
        {
            return true;
        }
        else if(topLeft.getText() == midMid.getText() && topLeft.getText() == botRight.getText())
        {
            return true;
        }
        else if(botLeft.getText() == midMid.getText() && botLeft.getText() == topRight.getText())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //this function resets all the buttons on the board
    public void resetButtons() //resets the board to a clean one, also resets game board
    {
        topLeft.setText(""); //resets what they hold
        topMid.setText(" ");
        topRight.setText("  ");
        midLeft.setText("   ");
        midMid.setText("    ");
        midRight.setText("     ");
        botLeft.setText("      ");
        botMid.setText("       ");
        botRight.setText("        ");
        
        topLeft.setIcon(null); //resets what they hold
        topMid.setIcon(null);
        topRight.setIcon(null);
        midLeft.setIcon(null);
        midMid.setIcon(null);
        midRight.setIcon(null);
        botLeft.setIcon(null);
        botMid.setIcon(null);
        botRight.setIcon(null);
        
        
        topLeft.setEnabled(false); //resets if they are enabled or not
        topMid.setEnabled(false);
        topRight.setEnabled(false);
        midLeft.setEnabled(false);
        midMid.setEnabled(false);
        midRight.setEnabled(false);
        botLeft.setEnabled(false);
        botMid.setEnabled(false);
        botRight.setEnabled(false);
        
        playerOneName.setEditable(true);
        playerTwoName.setEditable(true);
        
        userTurn = 0;
        
        bottomMessage.setText("Welcome to Tic-Tac-Toe");
    }
    
    //this function resets all the stats in the upper panel
    public void resetStats()
    {
        winCounter1 = 0; //sets integer win/loss values back to zero
        winCounter2 = 0;
        lossCounter1 = 0;
        lossCounter2 = 0;
        
        winsCount1.setText(Integer.toString(winCounter1)); //actually sets the labels to 0 wins/loss
        winsCount2.setText(Integer.toString(winCounter2));
        lossCount1.setText(Integer.toString(lossCounter1));
        lossCount2.setText(Integer.toString(lossCounter2));
        
        playerOneName.setText(""); //resets the text
        playerTwoName.setText("");
    }
    
    //this function checks to see if the entered names are valid. 
    public boolean ErrorMessage(String p1Name, String p2Name)
    {
        boolean setError = false; //this boolean holds whether an error is present or not in either names
        if(p1Name == null || p1Name.isEmpty() || p1Name.trim().isEmpty()) // trim causes all whitespace to be "trimmed" out of the string. The isEmpty then checks for the case of an all space-case being empty.
        {
            setError = true; //an error is found
        }
        
        if(p2Name == null || p2Name.isEmpty() || p2Name.trim().isEmpty()) //checks player 2's name
        {
            setError = true; //an error is found
        }
        
        return setError; //returns the boolean
        
    }
    
    
public static void main(String[] args) {
    new TicTacToe();
        
    }
}