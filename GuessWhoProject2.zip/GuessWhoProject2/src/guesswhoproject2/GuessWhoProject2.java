/*
    DEVELOPERS: DONOVAN FARAR & ANTHONY KASKURS
    TITLE: GUESS WHO
    CLASS: CPSC 224
    ASSIGNMENT: FINAL PROJECT
 */

package guesswhoproject2;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import java.util.Random;
import java.util.Arrays;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;


//This class will build a JFrame game of Guess Who
public class GuessWhoProject2 extends JFrame{
    
    private JPanel upperPanel; //represents the panel in the NORTH portion of the JFrame
    private JPanel lowerPanel; //represents the panel in the SOUTH portion of the JFrame
    private JPanel gameBoardPanel; //repreesents the panel in the CENTER portion of the JFrame
    private JPanel startGameResetGamePanel; //Represtents the inner panel that holds the start game and reset buttons
    private JPanel radioButtonPanel; //represents the inner panel that holds the game mode radio buttons
    private JRadioButton videoGameCharacterRadioButton; //radio button for video game characters
    private JRadioButton comicBookCharacterRadioButton; //radio button for comic book characters
    private JRadioButton loadOwnImagesRadioButton; //radio button for loading your own image
    private ButtonGroup gameVersionGroup; //allows only one of the options to be selected at a time (radio buttons).
    private JButton startGameButton; 
    private JButton resetGameButton;
    private JLabel specialCharacter; //holds the picture of the special character the other player is guessing.
    private JButton finishedTurnButton; 
    private JButton finalGuessButton;
    private JPanel player1Panel; //player 1 info panel
    private JPanel player2Panel; //player 2 info panel
    private JLabel player1Label; 
    private JTextField player1NameEnter;
    private JLabel player1Wins;
    private JLabel player1Loss;
    private JLabel player2Label;
    private JTextField player2NameEnter;
    private JLabel player2Wins;
    private JLabel player2Loss;
    private JPanel loadingScreenPanel; //the loading screen panel to be shown between turns
    private JLabel loadingScreenImageLabel; //the label that goes on the loading panel to be shown
    private ImageIcon loading = new ImageIcon("loading.jpg"); //the load image we selected
    private JPanel specialCharacterLabel = new JPanel();
    private JLabel specialCharacterImage = new JLabel();
    private JPanel specialCharacterIntroPanel; //this is the panel that is used to show the players who their special characters are
    private JLabel specialCharacterIntroLabel;
    private JLayeredPane layer = new JLayeredPane(); //creates a layered pane so we can add components on top of others
    private Random rand = new Random(); //creates a new random object to be used for character selection
    private int randomNumberPlayer1 = 0; //holds player 1's unique value
    private int randomNumberPlayer2 = 0; //holds player 2's unique value
    private int p1Wins = 0; //represents the wins of P1
    private int p1Loss = 0; //represents the losses of p2
    private int p2Wins = 0;
    private int p2Loss = 0;
    private int turnCounter = 0; //counts the turns and who's turn it is
    private int numClicks = 0; //counts the number of clicks during the loadingscreen phase
    private int hidePlayerIconClicks = 0; //counts number of clicks during the loadin screen phase

    private ImageIcon[] videoGameCharactersImages = new ImageIcon[25]; //holds the images of the video game characters
    private String[] videoGameCharacterNames = new String[25]; //holds the names of the video game characters
    private ImageIcon[] comicBookCharacterImages = new ImageIcon[25]; //holds the images of the comic book characters
    private String[] comicBookCharacterNames = new String[25]; //holds the names of the comic book characters
    private ImageIcon[] loadedImages = new ImageIcon[25];  //holds the loaded images that user selects
    private String[] loadedImagesNames = new String[25]; //holds the names of loaded images that user selects
    private JButton[] gameBoardButtons = new JButton[25]; //holds the buttons seen on the game board that hold the images
    private boolean[] saveBoard = new boolean[25]; //holds flags to see whether a game board button is selected or not
    private boolean player1Board[] = new boolean[25]; //player 1's game board
    private boolean player2Board[] = new boolean[25];

    
    //The constructor builds the UI, loads the images, and packs
    public GuessWhoProject2()
    {
        setTitle("Guess Who");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setVisible(true);
        loadVideoGameInformation(); //loads images of videoGameCharacters and names
        loadComicBookInformation(); //loads images and names of comic book characters     
        buildUpperPanel(); //builds the upper panel
        buildMiddlePanel(); //builds the middle panel
        buildLowerPanel(); //builds the lower panel
        buildSplashScreen(); //builds the loading screen
        
        layer.setLayout(new BorderLayout()); //creates a new layered panel
        layer.add(upperPanel, BorderLayout.NORTH, new Integer(1)); //ads the panel to the layered panel at lowest layer
        layer.add(lowerPanel, BorderLayout.SOUTH, new Integer(1));
        layer.add(gameBoardPanel, BorderLayout.CENTER, new Integer(1));
        add(layer); //adds the layerePanel to the UI
        pack();
    }
    
    
    //builds the upperPanel that contains the players names, radio buttons, and start/cancel buttons
    private void buildUpperPanel()
    {
        upperPanel = new JPanel(); 
        upperPanel.setLayout(new GridLayout(2, 2)); //creates a grid layout
        
        videoGameCharacterRadioButton = new JRadioButton("Video Game Characters"); //creates the radio button
        comicBookCharacterRadioButton = new JRadioButton("Comic Book Characters"); 
        loadOwnImagesRadioButton = new JRadioButton("Load your own images from folder");
        loadOwnImagesRadioButton.addActionListener(new fileSelector()); //adds the radio button to the fileSelector class.
        gameVersionGroup = new ButtonGroup(); //creates a button group for our selection radio buttons
        gameVersionGroup.add(videoGameCharacterRadioButton); //adds the buttons to the group
        gameVersionGroup.add(comicBookCharacterRadioButton);
        gameVersionGroup.add(loadOwnImagesRadioButton);
        radioButtonPanel = new JPanel(); //creates the panel that will hold the radio buttons
        radioButtonPanel.setBorder(BorderFactory.createTitledBorder("SELECT GAME-MODE")); //creates border
        radioButtonPanel.setLayout(new GridLayout(2, 2));
        radioButtonPanel.add(videoGameCharacterRadioButton);
        radioButtonPanel.add(comicBookCharacterRadioButton);
        radioButtonPanel.add(loadOwnImagesRadioButton);
        
        startGameResetGamePanel = new JPanel(); //starts creatio of the startGameResetGamePanel
        startGameButton = new JButton("Start Game!"); //creates the buttons
        resetGameButton = new JButton("Reset Board!");
        startGameResetGamePanel.setBorder(BorderFactory.createTitledBorder("START GAME AND RESET OPTIONS"));
        startGameResetGamePanel.setLayout(new GridLayout(1, 2));
        startGameButton.addActionListener(new startCancelButtonListener()); //adds the buttons to the inner class interface
        resetGameButton.addActionListener(new startCancelButtonListener());
        startGameResetGamePanel.add(startGameButton);
        startGameResetGamePanel.add(resetGameButton);
        
        player1Panel = new JPanel(); //starts creation of the player 1 info panel
        player1Panel.setBorder(BorderFactory.createTitledBorder("PLAYER 1 INFO")); //creates the little border around the bottom left with a title
        player1Panel.setLayout(new GridLayout(2,2));
        player1Label = new JLabel("Player 1:");
        player1NameEnter = new JTextField("");
        player1Wins = new JLabel("WINS: " + p1Wins); //come back here to update
        player1Loss = new JLabel("LOSSES: " + p1Loss); //come back here to update
        player1Panel.add(player1Label); //goes top left to bottom right (like a book)
        player1Panel.add(player1NameEnter);
        player1Panel.add(player1Wins);
        player1Panel.add(player1Loss);
        
        player2Panel = new JPanel(); //starts creation of the player 2 info panel
        player2Panel.setBorder(BorderFactory.createTitledBorder("PLAYER 2 INFO"));
        player2Panel.setLayout(new GridLayout(2,2));
        player2Label = new JLabel("Player 2:");
        player2NameEnter = new JTextField("");
        player2Wins = new JLabel("WINS: " + p2Wins); //come back here to update
        player2Loss = new JLabel("LOSSES: " + p2Loss); //come back here to update
        player2Panel.add(player2Label); //goes top left to bottom right (like a book)
        player2Panel.add(player2NameEnter);
        player2Panel.add(player2Wins);
        player2Panel.add(player2Loss);
        
        upperPanel.add(player1Panel); //adds all the sections to the upperPanel
        upperPanel.add(radioButtonPanel);
        upperPanel.add(player2Panel);
        upperPanel.add(startGameResetGamePanel);
    }
    
    
    //builds the middlePanel that contains the game board buttons
    private void buildMiddlePanel()
    {
        gameBoardPanel = new JPanel();
        gameBoardPanel.setLayout(new GridLayout(5, 5)); //5 by 5 layout
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i] = new JButton();
            gameBoardPanel.add(gameBoardButtons[i]);
            gameBoardButtons[i].addActionListener(new gameButtonListener()); //adds the buttons to gameButtonListener class
        }

        for(int i = 0; i < saveBoard.length; i++)//initializing the saveBoard and player1Boards and player2Boards to be UNSHADED
        {
            saveBoard[i] = true; // begin transition board
        }
        
        for(int i = 0; i < player1Board.length; i++)
        {
            player1Board[i] = true;
        }
        
        for(int i = 0; i <  player2Board.length; i++)
        {
             player2Board[i] = true;
        }

        
    }
    

    //builds lower panel that contains the player's special character, guess, and switch turn buttons
    private void buildLowerPanel()
    {
        lowerPanel = new JPanel();
        specialCharacter = new JLabel(""); //this JLabel will hold the random character image
        specialCharacter.setBorder(BorderFactory.createTitledBorder("SPECIAL CHARACTER"));
        finishedTurnButton = new JButton("FINISH TURN"); //creates the finish turn button
        finalGuessButton = new JButton("MAKE FINAL GUESS"); //creates the finalGuessButton
        finishedTurnButton.addActionListener(new finishTurnandGuess()); //adds each button to their respective Listener classes
        finalGuessButton.addActionListener(new makeGuessListener());
        
        randomNumberPlayer1 = rand.nextInt(25); //represent which special character each individual will have 
        randomNumberPlayer2 = rand.nextInt(25);//gets a random number between zero and 24

        lowerPanel.add(specialCharacter);
        lowerPanel.add(finishedTurnButton);
        lowerPanel.add(finalGuessButton);
    }
    
    
    //this function loads the video game information (files and names) into arrays
    public void loadVideoGameInformation() //loads the images into the array videoGameCharactersImages
    {
        videoGameCharactersImages[0] = new ImageIcon("1commanderShepard.jpg");
        videoGameCharactersImages[1] = new ImageIcon("2ezioAuditore.jpg");
        videoGameCharactersImages[2] = new ImageIcon("3earthwormJim.jpg");
        videoGameCharactersImages[3] = new ImageIcon("4kidIcarus.jpg");
        videoGameCharactersImages[4] = new ImageIcon("5fargoth.jpg");
        videoGameCharactersImages[5] = new ImageIcon("6mccree.jpg");
        videoGameCharactersImages[6] = new ImageIcon("7handsomeJack.jpg");
        videoGameCharactersImages[7] = new ImageIcon("8rayman.jpg");
        videoGameCharactersImages[8] = new ImageIcon("9diddyKong.jpg");
        videoGameCharactersImages[9] = new ImageIcon("10spyro.jpg");
        videoGameCharactersImages[10] = new ImageIcon("11nathanDrake.jpg");
        videoGameCharactersImages[11] = new ImageIcon("12gordanFreeman.jpg");
        videoGameCharactersImages[12] = new ImageIcon("13glados.jpg");
        videoGameCharactersImages[13] = new ImageIcon("14samus.jpg");
        videoGameCharactersImages[14] = new ImageIcon("15agent47.jpg");
        videoGameCharactersImages[15] = new ImageIcon("16samFisher.jpg");
        videoGameCharactersImages[16] = new ImageIcon("17sonic.jpg");
        videoGameCharactersImages[17] = new ImageIcon("18banjoKazooie.jpg");
        videoGameCharactersImages[18] = new ImageIcon("19pikachu.jpg");
        videoGameCharactersImages[19] = new ImageIcon("20bowser.jpg");
        videoGameCharactersImages[20] = new ImageIcon("21megaMan.jpg");
        videoGameCharactersImages[21] = new ImageIcon("22kratos.jpg");
        videoGameCharactersImages[22] = new ImageIcon("23geralt.jpg");
        videoGameCharactersImages[23] = new ImageIcon("24laraCroft.jpg");
        videoGameCharactersImages[24] = new ImageIcon("25link.jpg");
        
        videoGameCharacterNames[0] = "Commander Shepard";
        videoGameCharacterNames[1] = "Ezio Auditore";
        videoGameCharacterNames[2] = "EarthWorm Jim";
        videoGameCharacterNames[3] = "Kid Icarus";
        videoGameCharacterNames[4] = "Fargoth";
        videoGameCharacterNames[5] = "McCree";
        videoGameCharacterNames[6] = "Handsome Jack";
        videoGameCharacterNames[7] = "Rayman";
        videoGameCharacterNames[8] = "Diddy Kong";
        videoGameCharacterNames[9] = "Spyro";
        videoGameCharacterNames[10] = "Nathan Drake";
        videoGameCharacterNames[11] = "Gordan Freeman";
        videoGameCharacterNames[12] = "GlADos";
        videoGameCharacterNames[13] = "Samus";
        videoGameCharacterNames[14] = "Agent 47";
        videoGameCharacterNames[15] = "Sam Fisher";
        videoGameCharacterNames[16] = "Sonic";
        videoGameCharacterNames[17] = "Banjo Kazooie";
        videoGameCharacterNames[18] = "Pikachu";
        videoGameCharacterNames[19] = "Bowser";
        videoGameCharacterNames[20] = "Megaman";
        videoGameCharacterNames[21] = "Kratos";
        videoGameCharacterNames[22] = "Geralt";
        videoGameCharacterNames[23] = "Lara Croft";
        videoGameCharacterNames[24] = "Link";
    }
    
    
    //this function loads the comic book information (files and names) into arrays
    public void loadComicBookInformation()
    {
        comicBookCharacterImages[0] = new ImageIcon("26drDoom.jpg");
        comicBookCharacterImages[1] = new ImageIcon("27captainAmerica.jpg");
        comicBookCharacterImages[2] = new ImageIcon("28wonderWoman.jpg");
        comicBookCharacterImages[3] = new ImageIcon("29thePunisher.jpg");
        comicBookCharacterImages[4] = new ImageIcon("30ironMan.jpg");
        comicBookCharacterImages[5] = new ImageIcon("31rorschach.jpg");
        comicBookCharacterImages[6] = new ImageIcon("32theHulk.jpg");
        comicBookCharacterImages[7] = new ImageIcon("33theThing.jpg");
        comicBookCharacterImages[8] = new ImageIcon("34theJoker.jpg");
        comicBookCharacterImages[9] = new ImageIcon("35spiderman.jpg");
        comicBookCharacterImages[10] = new ImageIcon("36wolverine.jpg");
        comicBookCharacterImages[11] = new ImageIcon("37batman.jpg");
        comicBookCharacterImages[12] = new ImageIcon("38superman.jpg");
        comicBookCharacterImages[13] = new ImageIcon("39theTick.jpg");
        comicBookCharacterImages[14] = new ImageIcon("40venom.jpg");
        comicBookCharacterImages[15] = new ImageIcon("41doctorStrange.jpg");
        comicBookCharacterImages[16] = new ImageIcon("42hellboy.jpg");
        comicBookCharacterImages[17] = new ImageIcon("43deadpool.jpg");
        comicBookCharacterImages[18] = new ImageIcon("44greenLantern.jpg");
        comicBookCharacterImages[19] = new ImageIcon("45astroBoy.jpg");
        comicBookCharacterImages[20] = new ImageIcon("46death.jpg");
        comicBookCharacterImages[21] = new ImageIcon("47haloJones.jpg");
        comicBookCharacterImages[22] = new ImageIcon("48daredevil.jpg");
        comicBookCharacterImages[23] = new ImageIcon("49antman.jpg");
        comicBookCharacterImages[24] = new ImageIcon("50Thanos.jpg");
        
        comicBookCharacterNames[0] = "Dr. Doom";
        comicBookCharacterNames[1] = "Captain America";
        comicBookCharacterNames[2] = "Wonder Woman";
        comicBookCharacterNames[3] = "The Punisher";
        comicBookCharacterNames[4] = "Iron Man";
        comicBookCharacterNames[5] = "Rorschach";
        comicBookCharacterNames[6] = "The Hulk";
        comicBookCharacterNames[7] = "The Thing";
        comicBookCharacterNames[8] = "The Joker";
        comicBookCharacterNames[9] = "Spiderman";
        comicBookCharacterNames[10] = "Wolverine";
        comicBookCharacterNames[11] = "Batman";
        comicBookCharacterNames[12] = "Superman";
        comicBookCharacterNames[13] = "The Tick";
        comicBookCharacterNames[14] = "Venom";
        comicBookCharacterNames[15] = "Doctor Strange";
        comicBookCharacterNames[16] = "Hellboy";
        comicBookCharacterNames[17] = "Deadpool";
        comicBookCharacterNames[18] = "Green Lantern";
        comicBookCharacterNames[19] = "Astro Boy";
        comicBookCharacterNames[20] = "Death";
        comicBookCharacterNames[21] = "Halo Jones";
        comicBookCharacterNames[22] = "Daredevil";
        comicBookCharacterNames[23] = "Antman";
        comicBookCharacterNames[24] = "Thanos";
    }
    
    
    //this function will reset the game board back to normal (in case of restart or error)
    public void resetBoard() //resets the game board back to normal
    {
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i].setIcon(null);
            gameBoardButtons[i].setText(null);
            gameBoardButtons[i].setBackground(new JButton().getBackground());
            player1Board[i] = true;
            player2Board[i] = true;
        }
        
        gameVersionGroup.clearSelection();
        specialCharacter.setIcon(null); //sets the icon to the player 1's special character
        specialCharacter.setText(null);
        numClicks = 0;
        turnCounter = 0;
        startGameButton.setEnabled(true);
        removeSplashScreen(); //removes the loading screen as well just in case it is present
    }
    
    
    //this function accepts a button on the game board (that the user clicks). If the player1Board is not shaded, then it will change the background color to red. If its shaded, it reverts the color
    public void shadeInOrNotPlayer1(int position) //executes only if we're on player 1's turn
    {
        if(player1Board[position] == true) //"if its not shaded! Shade it!
        {
            gameBoardButtons[position].setBackground(Color.RED);
        } else 
        {
            gameBoardButtons[position].setBackground(new JButton().getBackground());
        }
    } 
     

    //this function accepts a button on the game board (that the user clicks). If the player1Board is not shaded, then it will change the background color to red. If its shaded, it reverts the color
    public void shadeInOrNotPlayer2(int position) //executes only if we're on player 2's turn
    {
        if(player2Board[position] == true)
        {
            gameBoardButtons[position].setBackground(Color.RED);
        }
        
        else
        {
             gameBoardButtons[position].setBackground(new JButton().getBackground());
        }
    }
    
    
    //this function builds a "splash loading screen" that will be used to cover the gameboard in-between turns. It is called in other Listener functions
    private void buildSplashScreen()
    {
     loadingScreenPanel = new JPanel();
     loadingScreenPanel.addMouseListener(new mouseListener()); //adds to the mouseListener internal class
     loadingScreenImageLabel = new JLabel();
     loadingScreenImageLabel.setIcon(loading);
     loadingScreenPanel.add(loadingScreenImageLabel);
    }
    
    
    //this method shows the loading screen we just created when called
    private void showSplashScreen()
    {
        layer.add(loadingScreenPanel, BorderLayout.CENTER, new Integer(2)); //adding the image to the screen on a layer above all other layers
        layer.remove(gameBoardPanel); //removing bottom layer
        specialCharacter.setText("Guess Who");
    }
    
    
    //this method ermooves the loadings screen when called
    private void removeSplashScreen()
    {
        layer.remove(loadingScreenPanel); //removes the loading screen
        layer.add(gameBoardPanel, BorderLayout.CENTER, new Integer(1)); //adds back the game board panel 
    }
    
    
    //this method builds the "Spsecial Character" panel seen at the beginning of the game where users peek at their characters secretly
    private void buildSpecialCharacterPanel()
    {
        specialCharacterIntroPanel = new JPanel();
        specialCharacterIntroLabel = new JLabel();
        specialCharacterIntroPanel.setLayout(new GridLayout(1, 1));
        specialCharacterIntroPanel.addMouseListener(new specialCharacterMouseListener());
        
        //if statements to see which radio button is selected
        if(videoGameCharacterRadioButton.isSelected())
        {
            specialCharacterIntroLabel.setIcon(videoGameCharactersImages[randomNumberPlayer1]); //sets the icon to player 1's character first
        }
        
        else if(comicBookCharacterRadioButton.isSelected())
        {
            specialCharacterIntroLabel.setIcon(comicBookCharacterImages[randomNumberPlayer1]);
        }
        
        else if(loadOwnImagesRadioButton.isSelected())
        {
            specialCharacterIntroLabel.setIcon(loadedImages[randomNumberPlayer1]);
        }
        
        specialCharacterIntroLabel.setText("Look over your character Player 1. When done, click screen for instructions!");
        specialCharacterIntroPanel.add(specialCharacterIntroLabel);
        layer.remove(gameBoardPanel); //removes the gamepanel
        layer.remove(lowerPanel); //removes the lower SOUTH panel
        layer.add(specialCharacterIntroPanel, BorderLayout.CENTER, new Integer(2)); //adds this panel into the frame
        pack();
    }
    
    
    
    
    
    
    
    
    
    
    
    

    
    private class gameButtonListener implements ActionListener //this fires when we click any button on board
    {
        public void actionPerformed(ActionEvent e)
        {
                String name = (e.getActionCommand());
                

                for (int i = 0; i < gameBoardButtons.length; i++)
                {
                    if(name.equals(videoGameCharacterNames[i]) || name.equals(loadedImagesNames[i]) || name.equals(comicBookCharacterNames[i]))
                    {
                        if(turnCounter % 2 == 0 && player1Board[i] == true) //if its player 1's turn
                        {
                            shadeInOrNotPlayer1(i);
                            player1Board[i] = false;
                        }
                        
                        else if(turnCounter % 2 == 0 && player1Board[i] == false)
                        {
                            shadeInOrNotPlayer1(i);
                            player1Board[i] = true;
                        }
                        
                        else if(turnCounter % 2 != 0 && player2Board[i] == true) //if its player 2's turn
                        {
                            shadeInOrNotPlayer2(i);
                            player2Board[i] = false;
                        }
                        
                        else if(turnCounter % 2 != 0 && player2Board[i] == false)
                        {
                            shadeInOrNotPlayer2(i);
                            player2Board[i] = true;
                        }
                    }
                    
                    
                }
        }

    }
    
    
    //this method resizes the images that the user uploads to fit the screen
    public void resize()
    {
        for(int i = 0; i < loadedImages.length; i++) //loadedImages is my ImageIcon array
        {
            ImageIcon newImageIcon = new ImageIcon(loadedImages[i].getImage()); //gets the image that was loaded in and creates a newImageIcon from it
            Image IMG = newImageIcon.getImage(); //Gets an Image object from the ImageIcon
            Image newIMG = IMG.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH); //rescales the Image to a newIMG
            newImageIcon = new ImageIcon(newIMG); //sets the newImageIcon to the Image
            loadedImages[i] = newImageIcon; //sets the loadedImages back to the resized image
        }
    }
    
    
    //this inner class handles events when either the start or cancel buttons are selected.
    private class startCancelButtonListener implements ActionListener //starts game
    {
        public void actionPerformed(ActionEvent e)
        { 
            if(e.getSource() == startGameButton) //what happens if start button is selected
            {
                if(videoGameCharacterRadioButton.isSelected()) //what happens if we're in video game mode
                {
                    for(int i = 0; i < gameBoardButtons.length; i++) //adds the buttons
                    {
                        gameBoardButtons[i].setIcon(videoGameCharactersImages[i]); //loading the board with images
                        gameBoardButtons[i].setText(videoGameCharacterNames[i]); //loading the board with text on who the person is
                        gameBoardButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
                        startGameButton.setEnabled(false); //deselect the start button
                        randomNumberPlayer1 = rand.nextInt(25); //gets a random number that will be the player's individual special character 
                        randomNumberPlayer2 = rand.nextInt(25); 
                        specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer1]); //sets the icon to the player 1's special character
                        specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer1]); //sets the text the the player 1's special character
                        pack();
                    }
                    buildSpecialCharacterPanel(); //calls the function that builds the special character intro panels
                }
                
                else if(comicBookCharacterRadioButton.isSelected()) //does the same if the comic book button is selected
                {
                    for(int i = 0; i < gameBoardButtons.length; i++)
                    {
                        gameBoardButtons[i].setIcon(comicBookCharacterImages[i]);
                        gameBoardButtons[i].setText(comicBookCharacterNames[i]);
                        gameBoardButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
                        startGameButton.setEnabled(false);
                        randomNumberPlayer1 = rand.nextInt(25);
                        randomNumberPlayer2 = rand.nextInt(25);
                        specialCharacter.setIcon(comicBookCharacterImages[randomNumberPlayer1]);
                        specialCharacter.setText(comicBookCharacterNames[randomNumberPlayer1]);
                        pack();
                    }
                    buildSpecialCharacterPanel();
                }
                
                else if(loadOwnImagesRadioButton.isSelected()) //does the same if the select own image button is selected
                {
                    for(int i = 0; i < gameBoardButtons.length; i++)
                    {
                        gameBoardButtons[i].setIcon(loadedImages[i]);
                        gameBoardButtons[i].setText(loadedImagesNames[i]);
                        gameBoardButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
                        startGameButton.setEnabled(false);
                        randomNumberPlayer1 = rand.nextInt(25);
                        randomNumberPlayer2 = rand.nextInt(25);
                        specialCharacter.setIcon(loadedImages[randomNumberPlayer1]); //sets the icon to the player 1's special character
                        specialCharacter.setText(loadedImagesNames[randomNumberPlayer1]);
                        pack();
                    }
                    buildSpecialCharacterPanel();  
                }  
            }
            
            else if(e.getSource() == resetGameButton) //if the reset button is clicked, but reset the game board
            {
                resetBoard();
                startGameButton.setEnabled(true);
            }
        }
    }
    
    
    //this class handles the events when we hit the finish turn button! we are not making a guess here.
    private class finishTurnandGuess implements ActionListener //this controlls the logic when the user switches turns. Mostly memorizing the shading of buttons.
    {
        public void actionPerformed(ActionEvent e)
        {
            turnCounter++; //need to increment here to update the turn, not at the end

            if(turnCounter % 2 == 0) //logic for different game modes goes here; if its player 1's turn
            {
                showSplashScreen(); //we start by showing the splash screen to mask the game board and player characters.
                if(videoGameCharacterRadioButton.isSelected())
                {
                    if(hidePlayerIconClicks == 0) //this checks to see if the player has clicked on the loading screen. If zero, we need to set special characters to null
                    {
                     specialCharacter.setIcon(null);  //so player wont see the other player's special character
                     specialCharacter.setText(null);
                    }
                }
                else if(comicBookCharacterRadioButton.isSelected()) //same process for the other version
                {
                    if(hidePlayerIconClicks == 0)
                    {
                     specialCharacter.setIcon(null); 
                     specialCharacter.setText(null);
                    }
                }
                else if(loadOwnImagesRadioButton.isSelected()) //same process for this version
                {
                    specialCharacter.setIcon(null);
                    specialCharacter.setText(null);
                }

                for(int i = 0; i < player1Board.length; i++) //this for loop will then go and shade in the player's board to remember what the user has deselected in prior turns
                {
                    gameBoardButtons[i].setBackground(new JButton().getBackground()); //clears the colors 
                    if(player1Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(Color.RED);
                    }
                    else if(player1Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(new JButton().getBackground());
                    }
                }
            }
            
            else if(turnCounter % 2 != 0) //does the same if it's player 2's turn
            {
                showSplashScreen();
                if(videoGameCharacterRadioButton.isSelected())
                {
                    if(hidePlayerIconClicks == 0)
                    {
                     specialCharacter.setIcon(null); 
                     specialCharacter.setText(null);
                    }
                    
                    else if(hidePlayerIconClicks == 1) //we need this extra portion for player 2's turn because we check and see if player 2 has clicked the screen in order to load his/her special characters
                    {
                        specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer2]); 
                        specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0;
                    } 

                }
                else if(comicBookCharacterRadioButton.isSelected()) //same code
                {
                    if(hidePlayerIconClicks == 0)
                    {
                        specialCharacter.setIcon(null); 
                        specialCharacter.setText(null);
                    }
                    else if(hidePlayerIconClicks == 1)
                    {
                        specialCharacter.setIcon(comicBookCharacterImages[randomNumberPlayer2]);
                        specialCharacter.setText(comicBookCharacterNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0; 
                    }
                }
                else if(loadOwnImagesRadioButton.isSelected())
                {
                    if(hidePlayerIconClicks == 0)
                    {
                        specialCharacter.setIcon(null); 
                        specialCharacter.setText(null);
                    }
                    else if(hidePlayerIconClicks == 1)
                    {
                        specialCharacter.setIcon(loadedImages[randomNumberPlayer2]);
                        specialCharacter.setText(loadedImagesNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0;  
                    }
                }
                
                //loads player 2's board to the screen
                for(int i = 0; i < player2Board.length; i++)
                {
                    gameBoardButtons[i].setBackground(new JButton().getBackground());
                    if(player2Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(Color.RED);
                    }
                    else if(player2Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(new JButton().getBackground());
                    }
                }
            }
        }
    }
    
    
    //this inner class handles the events if the make guess button is clicked by yser
    private class makeGuessListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if(turnCounter % 2 == 0) //if it's player 1's turn
            {
                String guess1 = JOptionPane.showInputDialog("Please type in your guess. Not case sensitive"); //output in dialog box
                if(videoGameCharacterRadioButton.isSelected())
                {
                    if(guess1.equalsIgnoreCase(videoGameCharacterNames[randomNumberPlayer2])) //if their guess equals the special character of player 2...
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player1Wins.setText("WINS: "+ ++p1Wins);
                        player2Loss.setText("LOSSES: " + ++p2Loss);
                        resetBoard(); //resets board
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                    }
                }
                else if(comicBookCharacterRadioButton.isSelected())
                {
                    if(guess1.equalsIgnoreCase(comicBookCharacterNames[randomNumberPlayer2]))
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player1Wins.setText("WINS: "+ ++p1Wins);
                        player2Loss.setText("LOSSES: " + ++p2Loss);
                        resetBoard();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick();
                    } 
                }
                else if(loadOwnImagesRadioButton.isSelected())
                {
                    if(guess1.equalsIgnoreCase(loadedImagesNames[randomNumberPlayer2]))
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player1Wins.setText("WINS: "+ ++p1Wins);
                        player2Loss.setText("LOSSES: " + ++p2Loss);
                        resetBoard();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                    }
                }

            }
            
            else if(turnCounter % 2 != 0) //if its player 2's turn
            {
                String guess2 = JOptionPane.showInputDialog("Please type in your guess. Not case sensitive");
                if(videoGameCharacterRadioButton.isSelected())
                {
                    if(guess2.equalsIgnoreCase(videoGameCharacterNames[randomNumberPlayer1]))
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player2Wins.setText("WINS: "+ ++p2Wins);
                        player1Loss.setText("LOSSES: " + ++p1Loss);
                        resetBoard();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                    }
                }
                else if(comicBookCharacterRadioButton.isSelected())
                {
                    if(guess2.equalsIgnoreCase(comicBookCharacterNames[randomNumberPlayer1]))
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player2Wins.setText("WINS: "+ ++p2Wins);
                        player1Loss.setText("LOSSES: " + ++p1Loss);
                        resetBoard();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                    }
                }
                else if(loadOwnImagesRadioButton.isSelected())
                {
                    if(guess2.equalsIgnoreCase(loadedImagesNames[randomNumberPlayer1]))
                    {
                        JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                        player2Wins.setText("WINS: "+ ++p2Wins);
                        player1Loss.setText("LOSSES: " + ++p1Loss);
                        resetBoard();
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                        finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                    }
                }
            }
        }
    }
    

    //this handles the events that occur when the user clicks on the loading screen to remove it
    private class mouseListener extends MouseAdapter
    {
        public void mouseClicked(MouseEvent e)
        {
            removeSplashScreen(); //it removes the splash screen
            hidePlayerIconClicks++; //increments this to show that the player has clicked on the loading screen, triggering whether the special characters are shown
            
            if(hidePlayerIconClicks == 1) //if the loading screen was clicked
            {
                if(videoGameCharacterRadioButton.isSelected())
                {
                    if(turnCounter % 2 == 0) //if it's player 1's turn we set the icon and text of special character to their character
                    {
                        specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer1]); 
                        specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer1]);
                        hidePlayerIconClicks = 0;
                    } 
                    else
                    {
                        specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer2]); 
                        specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0; 
                    }
                } 
                
                else if(comicBookCharacterRadioButton.isSelected()) 
                {

                    if(turnCounter % 2 == 0)
                    {
                        specialCharacter.setIcon(comicBookCharacterImages[randomNumberPlayer1]); 
                        specialCharacter.setText(comicBookCharacterNames[randomNumberPlayer1]);
                        hidePlayerIconClicks = 0;
                    } else
                    {
                        specialCharacter.setIcon(comicBookCharacterImages[randomNumberPlayer2]); 
                        specialCharacter.setText(comicBookCharacterNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0; 
                    }
                }
                
                else if(loadOwnImagesRadioButton.isSelected()) 
                {
                    if(turnCounter % 2 == 0)
                    {
                        specialCharacter.setIcon(loadedImages[randomNumberPlayer1]); 
                        specialCharacter.setText(loadedImagesNames[randomNumberPlayer1]);
                        hidePlayerIconClicks = 0;
                    } 
                    else
                    {
                        specialCharacter.setIcon(loadedImages[randomNumberPlayer2]); 
                        specialCharacter.setText(loadedImagesNames[randomNumberPlayer2]);
                        hidePlayerIconClicks = 0; 
                    }
                }
            }
        }
    }
    

    //this listener is activated when the characters are being shown their special characters
    private class specialCharacterMouseListener extends MouseAdapter
    {
        public void mouseClicked(MouseEvent e)
        {
            numClicks++; //increments num clicks. This determines who is looking at their respective special character

            if(numClicks == 1)
            {
                specialCharacterIntroLabel.setText("Pass the computer to Player 2. Player 2, please click the screen when ready");
                specialCharacterIntroLabel.setIcon(null);
            }
            if(numClicks == 2 && videoGameCharacterRadioButton.isSelected())
            {
                specialCharacterIntroLabel.setIcon(videoGameCharactersImages[randomNumberPlayer2]);
                specialCharacterIntroLabel.setText("When done looking at character, click the screen and pass the computer back to player 1");
            }
            else if(numClicks == 2 && loadOwnImagesRadioButton.isSelected())
            {
                specialCharacterIntroLabel.setIcon(loadedImages[randomNumberPlayer2]);
                specialCharacterIntroLabel.setText("When done looking at character, click on the screen and pass the computer back to player 1");
            }
            else if(numClicks == 2 && comicBookCharacterRadioButton.isSelected())
            {
                specialCharacterIntroLabel.setIcon(comicBookCharacterImages[randomNumberPlayer2]);
                specialCharacterIntroLabel.setText("When done looking at character, click on the screen and pass the computer back to player 1");
            }
            if(numClicks == 3)
            {
                specialCharacterIntroLabel.setIcon(null);
                specialCharacterIntroLabel.setText("PLEASE PRESS THE SCREEN TO START THE GAME!");
            }
            if(numClicks == 4)
            {
                layer.remove(specialCharacterIntroPanel);
                layer.add(gameBoardPanel, BorderLayout.CENTER, new Integer(1));
                layer.add(lowerPanel, BorderLayout.SOUTH, new Integer(1));
                pack();
            }
        }
    }
    
    
    //this class handles events when the user wants to load their own images in
    private class fileSelector implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            String[] paths = new String[25]; //creates a new string array to hold the paths of the images on the computer
            JOptionPane.showMessageDialog(null, "Please place all desired images into one folder.\nMake sure there are only 25 images in the folder and that they have names that represent what they are!");
            JFileChooser files = new JFileChooser(); //creates a new filechooser
            files.setCurrentDirectory(new File(System.getProperty("user.home"))); //starts the filechooser at the home directory
            FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images", "jpg", "png", "gif"); //only allows files with these extensions to be used
            files.addChoosableFileFilter(filter); //adds the filter
            files.setMultiSelectionEnabled(true); //makes it so you can select multiple files!
            files.showOpenDialog(null);
            File[] received = files.getSelectedFiles(); //loads selected files into the File array
            
            loadedImages = Arrays.stream(received).map(file -> new ImageIcon(file.getAbsolutePath())).toArray(ImageIcon[]::new); //converts the file array to the JImageIcon array
            
            for(int i = 0; i < received.length; i++)
            {
                paths[i] = received[i].getAbsolutePath(); //loads the file url paths into the paths array
                loadedImagesNames[i] = paths[i].substring(paths[i].lastIndexOf("\\") + 1, paths[i].indexOf(".")); //loads the names of the image without the path dashes and special characters
            }
            resize(); //resizes the images loaded in!
        }
    }
    

    //public method that will call the UI
    public static void main(String[] args) {
        new GuessWhoProject2();
    }
    
}