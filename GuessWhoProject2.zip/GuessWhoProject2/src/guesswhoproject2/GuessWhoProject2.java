/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject2;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners
import java.util.Random;
import java.util.Arrays;
import java.util.*;
import java.lang.Object;
import java.awt.SplashScreen;
import javax.swing.Timer;




public class GuessWhoProject2 extends JFrame{
    
    private JPanel upperPanel;
    private JPanel lowerPanel;
    private JPanel startGameResetGamePanel;
    private JPanel radioButtonPanel;
    private JRadioButton classMatesRadioButton;
    private JRadioButton videoGameCharacterRadioButton;
    private JRadioButton somethingRadioButton;
    private ButtonGroup gameVersionGroup; //allow only one of the options to be selected at a time (radio buttons).
    private JButton startGameButton;
    private JButton resetGameButton;
    
    private JLabel specialCharacter;
    private JButton finishedTurnButton;
    private JButton finalGuessButton;
    private Random rand = new Random();
    private int randomNumberPlayer1 = 0;
    private int randomNumberPlayer2 = 0;
    private int p1Wins = 0;
    private int p1Loss = 0;
    private int p2Wins = 0;
    private int p2Loss = 0;
    
    
    
    
    private JPanel gameBoardPanel;
    private JButton[] classMates = new JButton[25]; // 5 x 5
    private ImageIcon[] classMatesImages = new ImageIcon[25];
    
    //private JButton[] videoGameCharacters = new JButton[25];
    private ImageIcon[] videoGameCharactersImages = new ImageIcon[25];
    private String[] videoGameCharacterNames = new String[25];
    
    private JButton[] something = new JButton[25];
    private ImageIcon[] somethingImages = new ImageIcon[25];
    
    private JButton[] gameBoardButtons = new JButton[25];
    
    
    
    
    
    
    private boolean[] saveBoard = new boolean[25];
   // boolean[] player1Board = new boolean[25];
    
    private boolean player1Board[] = new boolean[25]; //player 1's game board

        
    private boolean player2Board[] = new boolean[25];
    
    
    
    
    
    
    private JPanel player1Panel;
    private JPanel player2Panel;
    private JLabel player1Label;
    private JTextField player1NameEnter;
    private JLabel player1Wins;
    private JLabel player1Loss;
    private JLabel player2Label;
    private JTextField player2NameEnter;
    private JLabel player2Wins;
    private JLabel player2Loss;
    
    private int turnCounter = 0;
    
    
    JLayeredPane layer = new JLayeredPane();
    
    JPanel loadingScreenPanel;
    JLabel loadingScreenImageLabel;
    ImageIcon loading = new ImageIcon("loading.png");
    
    JPanel loadingScreenPanelLower;
    JLabel loadingScreenImageLabelLower;
    ImageIcon loadingLower = new ImageIcon("black.jpg");
    
    
    
    Timer tmr;
    private int timerDelay = 1000;
    private int secondsCounter = 0;
    
    public GuessWhoProject2()
    {
        setTitle("Guess Who");
        //setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setVisible(true);
        loadVideoGameInformation();
        buildUpperPanel();
        buildMiddlePanel();
        buildLowerPanel();
        buildSplashScreen();
        buildSplashScreenLower();
        
        layer.setLayout(new BorderLayout());
        layer.add(upperPanel, BorderLayout.NORTH, new Integer(1));
        layer.add(lowerPanel, BorderLayout.SOUTH, new Integer(1));
        layer.add(gameBoardPanel, BorderLayout.CENTER, new Integer(1));
        
        
        add(layer);
        
        


        //add(upperPanel, BorderLayout.NORTH);
        //add(lowerPanel, BorderLayout.SOUTH);
        //add(gameBoardPanel, BorderLayout.CENTER);

        
        pack();
    }
    
    private void buildUpperPanel()
    {
        
        
        upperPanel = new JPanel();
        upperPanel.setLayout(new GridLayout(2, 2));
        
        
        classMatesRadioButton = new JRadioButton("Class Mates");
        videoGameCharacterRadioButton = new JRadioButton("Video Game Characters");
        somethingRadioButton = new JRadioButton("something"); 
        
        gameVersionGroup = new ButtonGroup(); //creates a button group for our selection radio buttons
        gameVersionGroup.add(classMatesRadioButton); //adds the buttons to the group
        gameVersionGroup.add(videoGameCharacterRadioButton);
        gameVersionGroup.add(somethingRadioButton);
        
        
        radioButtonPanel = new JPanel();
        radioButtonPanel.setBorder(BorderFactory.createTitledBorder("SELECT GAME-MODE"));
        radioButtonPanel.setLayout(new GridLayout(2, 2));
        radioButtonPanel.add(classMatesRadioButton);
        radioButtonPanel.add(videoGameCharacterRadioButton);
        radioButtonPanel.add(somethingRadioButton);
        
        
        startGameButton = new JButton("Start Game!");
        resetGameButton = new JButton("Reset Board!");
        startGameResetGamePanel = new JPanel();
        startGameResetGamePanel.setBorder(BorderFactory.createTitledBorder("START GAME AND RESET OPTIONS"));
        startGameResetGamePanel.setLayout(new GridLayout(1, 2));
        startGameButton.addActionListener(new startCancelButtonListener());
        resetGameButton.addActionListener(new startCancelButtonListener());
        startGameResetGamePanel.add(startGameButton);
        startGameResetGamePanel.add(resetGameButton);
        
        
        
        

        
        player1Panel = new JPanel();
        player1Panel.setBorder(BorderFactory.createTitledBorder("PLAYER 1 INFO")); //creates the little border around the bottom left with a title
        player1Panel.setLayout(new GridLayout(2,2));
        player1Label = new JLabel("Player 1:");
        player1NameEnter = new JTextField("");
        player1Wins = new JLabel("WINS: " + p1Wins); //come back here to update
        player1Loss = new JLabel("LOSSES: " + p1Loss); //come back here to update
        
        
        player1Panel.add(player1Label); //goes top left to bottom right (like a book)
        player1Panel.add(player1NameEnter);
        player1Panel.add(player1Wins);
        player1Panel.add(player1Loss);
        
        
        
        player2Panel = new JPanel();
        player2Panel.setBorder(BorderFactory.createTitledBorder("PLAYER 2 INFO"));
        player2Panel.setLayout(new GridLayout(2,2));
        player2Label = new JLabel("Player 2:");
        player2NameEnter = new JTextField("");
        player2Wins = new JLabel("WINS: " + p2Wins); //come back here to update
        player2Loss = new JLabel("LOSSES: " + p2Loss); //come back here to update
        
        
        player2Panel.add(player2Label); //goes top left to bottom right (like a book)
        player2Panel.add(player2NameEnter);
        player2Panel.add(player2Wins);
        player2Panel.add(player2Loss);
        
        
        upperPanel.add(player1Panel);
        upperPanel.add(radioButtonPanel);
        upperPanel.add(player2Panel);
        upperPanel.add(startGameResetGamePanel);
    }
    
    
    
    private void buildMiddlePanel()
    {
        gameBoardPanel = new JPanel();
        gameBoardPanel.setLayout(new GridLayout(5, 5));
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i] = new JButton();
            gameBoardPanel.add(gameBoardButtons[i]);
            gameBoardButtons[i].addActionListener(new gameButtonListener()); //adds the buttons to gameButtonListener class
        }
        
        


        
        
        
        
        for(int i = 0; i < saveBoard.length; i++)//initializing the saveBoard and player1Boards and player2Boards to be UNSHADED
        {
            saveBoard[i] = true; // begin transition board
        }
        
        for(int i = 0; i < player1Board.length; i++)
        {
            player1Board[i] = true;
        }
        
        for(int i = 0; i <  player2Board.length; i++)
        {
             player2Board[i] = true;
        }

        
    }
    

    
    private void buildLowerPanel()
    {
        lowerPanel = new JPanel();
        //lowerPanel.setLayout(new GridLayout(1, 3));
        specialCharacter = new JLabel(""); //this JLabel will hold the random character
        specialCharacter.setBorder(BorderFactory.createTitledBorder("SPECIAL CHARACTER"));
        finishedTurnButton = new JButton("FINISH TURN");
        finalGuessButton = new JButton("MAKE FINAL GUESS");
        finishedTurnButton.addActionListener(new finishTurnandGuess());
        finalGuessButton.addActionListener(new makeGuessListener());
        
        randomNumberPlayer1 = rand.nextInt(25);
        randomNumberPlayer2 = rand.nextInt(25);//gets a random number between zero and 24
        
        

        
        lowerPanel.add(specialCharacter);
        lowerPanel.add(finishedTurnButton);
        lowerPanel.add(finalGuessButton);
        
        
    }

    public void loadVideoGameInformation() //loads the images into the array videoGameCharactersImages
    {
        videoGameCharactersImages[0] = new ImageIcon("1commanderShepard.jpg");
        videoGameCharactersImages[1] = new ImageIcon("2ezioAuditore.jpg");
        videoGameCharactersImages[2] = new ImageIcon("3earthwormJim.jpg");
        videoGameCharactersImages[3] = new ImageIcon("4kidIcarus.jpg");
        videoGameCharactersImages[4] = new ImageIcon("5fargoth.jpg");
        videoGameCharactersImages[5] = new ImageIcon("6mccree.jpg");
        videoGameCharactersImages[6] = new ImageIcon("7handsomeJack.jpg");
        videoGameCharactersImages[7] = new ImageIcon("8rayman.jpg");
        videoGameCharactersImages[8] = new ImageIcon("9diddyKong.jpg");
        videoGameCharactersImages[9] = new ImageIcon("10spyro.jpg");
        videoGameCharactersImages[10] = new ImageIcon("11nathanDrake.jpg");
        videoGameCharactersImages[11] = new ImageIcon("12gordanFreeman.jpg");
        videoGameCharactersImages[12] = new ImageIcon("13glados.jpg");
        videoGameCharactersImages[13] = new ImageIcon("14samus.jpg");
        videoGameCharactersImages[14] = new ImageIcon("15agent47.jpg");
        videoGameCharactersImages[15] = new ImageIcon("16samFisher.jpg");
        videoGameCharactersImages[16] = new ImageIcon("17sonic.jpg");
        videoGameCharactersImages[17] = new ImageIcon("18banjoKazooie.jpg");
        videoGameCharactersImages[18] = new ImageIcon("19pikachu.jpg");
        videoGameCharactersImages[19] = new ImageIcon("20bowser.jpg");
        videoGameCharactersImages[20] = new ImageIcon("21megaMan.jpg");
        videoGameCharactersImages[21] = new ImageIcon("22kratos.jpg");
        videoGameCharactersImages[22] = new ImageIcon("23geralt.jpg");
        videoGameCharactersImages[23] = new ImageIcon("24laraCroft.jpg");
        videoGameCharactersImages[24] = new ImageIcon("25link.jpg");
        
        videoGameCharacterNames[0] = "Commander Shepard";
        videoGameCharacterNames[1] = "Ezio Auditore";
        videoGameCharacterNames[2] = "EarthWorm Jim";
        videoGameCharacterNames[3] = "Kid Icarus";
        videoGameCharacterNames[4] = "Fargoth";
        videoGameCharacterNames[5] = "McCree";
        videoGameCharacterNames[6] = "Handsome Jack";
        videoGameCharacterNames[7] = "Rayman";
        videoGameCharacterNames[8] = "Diddy Kong";
        videoGameCharacterNames[9] = "Spyro";
        videoGameCharacterNames[10] = "Nathan Drake";
        videoGameCharacterNames[11] = "Gordan Freeman";
        videoGameCharacterNames[12] = "GlADos";
        videoGameCharacterNames[13] = "Samus";
        videoGameCharacterNames[14] = "Agent 47";
        videoGameCharacterNames[15] = "Sam Fisher";
        videoGameCharacterNames[16] = "Sonic";
        videoGameCharacterNames[17] = "Banjo Kazooie";
        videoGameCharacterNames[18] = "Pikachu";
        videoGameCharacterNames[19] = "Bowser";
        videoGameCharacterNames[20] = "Megaman";
        videoGameCharacterNames[21] = "Kratos";
        videoGameCharacterNames[22] = "Geralt";
        videoGameCharacterNames[23] = "Lara Croft";
        videoGameCharacterNames[24] = "Link";
    }
    
    
    public void resetBoard() //resets the game board back to normal
    {
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i].setIcon(null);
            gameBoardButtons[i].setText(null);
            gameBoardButtons[i].setBackground(new JButton().getBackground());
            player1Board[i] = true;
            player2Board[i] = true;
        }
        
        gameVersionGroup.clearSelection();
        specialCharacter.setIcon(null); //sets the icon to the player 1's special character
        specialCharacter.setText(null);
    }
    
    
    
    private class gameButtonListener implements ActionListener //this fires when we click any button on board
    {
        public void actionPerformed(ActionEvent e)
        {
            
            
                String name = (e.getActionCommand());
                

                for (int i = 0; i < gameBoardButtons.length; i++)
                {
                    if(name.equals(videoGameCharacterNames[i]))
                    {
                        if(turnCounter % 2 == 0 && player1Board[i] == true) //if its player 1's turn
                        {
                            shadeInOrNotPlayer1(i);
                            player1Board[i] = false;
                        }
                        
                        else if(turnCounter % 2 == 0 && player1Board[i] == false)
                        {
                            shadeInOrNotPlayer1(i);
                            player1Board[i] = true;
                        }
                        
                        else if(turnCounter % 2 != 0 && player2Board[i] == true) //if its player 2's turn
                        {
                            shadeInOrNotPlayer2(i);
                            player2Board[i] = false;
                        }
                        
                        else if(turnCounter % 2 != 0 && player2Board[i] == false)
                        {
                            shadeInOrNotPlayer2(i);
                            player2Board[i] = true;
                        }
                    }
                    
                    
                }
                

            
 

            
            
        }

    }
    
    
    
    
    public void shadeInOrNotPlayer1(int position) //executes only if were on player 1's turn
    {
        
        
        if(player1Board[position] == true) //"if its not shaded! Shade it!
        {
            gameBoardButtons[position].setBackground(Color.RED);
            
        } else {
            gameBoardButtons[position].setBackground(new JButton().getBackground());
        }
    } 
    
    public void shadeInOrNotPlayer2(int position) //executes only if we're on player 2's turn
    {
        if(player2Board[position] == true)
        {
            gameBoardButtons[position].setBackground(Color.RED);
        }
        
        else
        {
             gameBoardButtons[position].setBackground(new JButton().getBackground());
        }
    }
    
    
    
    private class startCancelButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        { 

            
            if(e.getSource() == startGameButton)
            {
                if(classMatesRadioButton.isSelected())
                {
                    
                }
                
                else if(videoGameCharacterRadioButton.isSelected())
                {
                    for(int i = 0; i < gameBoardButtons.length; i++) //adds the buttons
                    {
                        
                        gameBoardButtons[i].setIcon(videoGameCharactersImages[i]);
                        gameBoardButtons[i].setText(videoGameCharacterNames[i]);
                        gameBoardButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
                        startGameButton.setEnabled(false);
                        
                        
                        randomNumberPlayer1 = rand.nextInt(25); //gets a random number that will be the player's individual special character 
                        randomNumberPlayer2 = rand.nextInt(25);
                        
                        specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer1]); //sets the icon to the player 1's special character
                        specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer1]); //sets the text the the player 1's special character
                        
                        pack();
                    }
                }
                
                else if(somethingRadioButton.isSelected())
                {
                    
                }
            }
            
            else if(e.getSource() == resetGameButton)
            {
                resetBoard();
                startGameButton.setEnabled(true);
            }
        }
    }
    
    
    
    
    private class finishTurnandGuess implements ActionListener //this controlls the logic when the user switches turns. Mostly memorizing the shading of buttons.
    {
        Timer tmr = new Timer(timerDelay, new timerListener()); //timerDelay is 1000
        
        public void actionPerformed(ActionEvent e)
        {
            turnCounter++; //need to increment here to update the turn, not at the end
            if(turnCounter % 2 == 0) //logic for different game modes goes here; if its player 1's turn
            {
                tmr.start(); //starts timer
                

                specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer1]); 
                specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer1]);
                
                for(int i = 0; i < player1Board.length; i++)
                {
                    gameBoardButtons[i].setBackground(new JButton().getBackground()); //clears the colors 
                    if(player1Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(Color.RED);
                    }
                    else if(player1Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(new JButton().getBackground());
                    }
                }
            }
            
            else if(turnCounter % 2 != 0)
            {
                tmr.start();
                
             
                specialCharacter.setIcon(videoGameCharactersImages[randomNumberPlayer2]); 
                specialCharacter.setText(videoGameCharacterNames[randomNumberPlayer2]);
                
                
                
                for(int i = 0; i < player2Board.length; i++)
                {
                    gameBoardButtons[i].setBackground(new JButton().getBackground());
                    if(player2Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(Color.RED);
                    }
                    else if(player2Board[i] == false)
                    {
                        gameBoardButtons[i].setBackground(new JButton().getBackground());
                    }
                }
            }
        }
    }
    
    
    private class makeGuessListener implements ActionListener //this controlls the logic when the user guesses
    {
        
        public void actionPerformed(ActionEvent e)
        {
            System.out.println("Player 1's character is:" + videoGameCharacterNames[randomNumberPlayer1]);
            System.out.println("Player 2's character is:" + videoGameCharacterNames[randomNumberPlayer2]);
            
            if(turnCounter % 2 == 0)
            {
                String guess1 = JOptionPane.showInputDialog("Please type in your guess. Not case sensitive");
                if(guess1.equalsIgnoreCase(videoGameCharacterNames[randomNumberPlayer2]))
                {
                    JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                    player1Wins.setText("WINS: "+ ++p1Wins);
                    player2Loss.setText("LOSSES: " + ++p2Loss);
                    resetBoard();
                    
                    
                    
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                    finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                }
                
            }
            
            else if(turnCounter % 2 != 0)
            {
                String guess2 = JOptionPane.showInputDialog("Please type in your guess. Not case sensitive");
                if(guess2.equalsIgnoreCase(videoGameCharacterNames[randomNumberPlayer1]))
                {
                    JOptionPane.showMessageDialog(null, "CONGRATS! YOU ARE THE WINNER!");
                    player2Wins.setText("WINS: "+ ++p2Wins);
                    player1Loss.setText("LOSSES: " + ++p1Loss);
                    resetBoard();
                    
                    
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "SORRY THAT IS INCORRECT!");
                    finishedTurnButton.doClick(); //automatically clicks the finishedTurnButton 
                }

                
            }
        }
    }
    
    private class timerListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            showSplashScreen(); //shows splash screen
            secondsCounter += timerDelay; //increments by 1000
            if(secondsCounter > 5000) 
            {
                secondsCounter = 0; //resets back to zero
                tmr.stop(); //stops timer
                removeSplashScreen();
            }
        }
    }
    

    

    
    
    
    private void buildSplashScreen()
    {
     loadingScreenPanel = new JPanel();
     loadingScreenImageLabel = new JLabel();
     loadingScreenImageLabel.setIcon(loading);
     loadingScreenPanel.add(loadingScreenImageLabel);
    }
    
    
    
    
    private void buildSplashScreenLower()
    {
     loadingScreenPanelLower = new JPanel();
     loadingScreenImageLabelLower = new JLabel();
     loadingScreenImageLabelLower.setIcon(loadingLower);
     loadingScreenPanelLower.add(loadingScreenImageLabelLower);
    }
    
    private void showSplashScreen()
    {

            layer.add(loadingScreenPanel, BorderLayout.CENTER, new Integer(2)); //adding the image to the screen
            layer.remove(gameBoardPanel); //removing bottom layer

            


        
        removeSplashScreen(); //removes the image
    }
    
    private void removeSplashScreen()
    {
        layer.remove(loadingScreenPanel);
        layer.add(gameBoardPanel, BorderLayout.CENTER, new Integer(1));
        //layer.remove(loadingScreenPanelLower);
        //layer.add(lowerPanel, BorderLayout.SOUTH, new Integer(1));
    }
    

    

    

    
    
    
    public static void main(String[] args) {
        //boolean player1Board[] = new boolean[25];

        //Arrays.fill(player1Board, 1, 25, true);
        

        
        
        

        
        new GuessWhoProject2();
    }
    
}