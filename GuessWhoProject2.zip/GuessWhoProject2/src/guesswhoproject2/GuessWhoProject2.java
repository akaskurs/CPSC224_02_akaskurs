/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject2;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners





public class GuessWhoProject2 extends JFrame{
    
    private JPanel upperPanel;
    private JRadioButton classMatesRadioButton;
    private JRadioButton videoGameCharacterRadioButton;
    private JRadioButton somethingRadioButton;
    private ButtonGroup gameVersionGroup; //allow only one of the options to be selected at a time (radio buttons).
    private JButton startGameButton;
    private JButton resetGameButton;
    
    
    
    
    private JPanel gameBoardPanel;
    private JButton[] classMates = new JButton[25]; // 5 x 5
    private ImageIcon[] classMatesImages = new ImageIcon[25];
    
    //private JButton[] videoGameCharacters = new JButton[25];
    private ImageIcon[] videoGameCharactersImages = new ImageIcon[25];
    private String[] videoGameCharacterNames = new String[25];
    
    private JButton[] something = new JButton[25];
    private ImageIcon[] somethingImages = new ImageIcon[25];
    
    private JButton[] gameBoardButtons = new JButton[25];
    
    private boolean[] saveBoard = new boolean[25];
    private boolean[] player1Board = new boolean[25];
    private boolean[] player2board = new boolean[25];
    
    
    private JPanel bothPlayerPanel;
    private JPanel player1Panel;
    private JPanel player2Panel;
    private JLabel player1Label;
    private JTextField player1NameEnter;
    private JLabel player1Wins;
    private JLabel player1Loss;
    private JLabel player2Label;
    private JTextField player2NameEnter;
    private JLabel player2Wins;
    private JLabel player2Loss;
    
    private int turnCounter = 0;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public GuessWhoProject2()
    {
        setTitle("Guess Who");
        //setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setVisible(true);
        loadVideoGameInformation();
        buildUpperPanel();
        buildMiddlePanel();
        buildLowerPanel();
        add(upperPanel, BorderLayout.NORTH);
        add(bothPlayerPanel, BorderLayout.SOUTH);
        add(gameBoardPanel, BorderLayout.CENTER);
        
        
        
        
        
        
        
        
        pack();
    }

    

    
    private void buildUpperPanel()
    {
        upperPanel = new JPanel();
        upperPanel.setLayout(new GridLayout(1, 5));
        
        classMatesRadioButton = new JRadioButton("Class Mates");
        videoGameCharacterRadioButton = new JRadioButton("Video Game Characters");
        somethingRadioButton = new JRadioButton("something");
        
        
        
        gameVersionGroup = new ButtonGroup(); //creates a button group for our selection radio buttons
        gameVersionGroup.add(classMatesRadioButton); //adds the buttons to the group
        gameVersionGroup.add(videoGameCharacterRadioButton);
        gameVersionGroup.add(somethingRadioButton);
        
        startGameButton = new JButton("Start Game!");
        resetGameButton = new JButton("Reset Board!");
        
        startGameButton.addActionListener(new startCancelButtonListener());
        resetGameButton.addActionListener(new startCancelButtonListener());
        
        
        upperPanel.add(classMatesRadioButton);
        upperPanel.add(videoGameCharacterRadioButton);
        upperPanel.add(somethingRadioButton);
        upperPanel.add(startGameButton);
        upperPanel.add(resetGameButton);
    }
    
    
    
    private void buildMiddlePanel()
    {
        gameBoardPanel = new JPanel();
        gameBoardPanel.setLayout(new GridLayout(5, 5));
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i] = new JButton();
            gameBoardPanel.add(gameBoardButtons[i]);
            gameBoardButtons[i].addActionListener(new gameButtonListener()); //adds the buttons to gameButtonListener class
        }
        
        for(int i = 0; i < saveBoard.length; i++)
        {
            saveBoard[i] = true; // begin transition board
        }
        
        for(int i = 0; i < player1Board.length; i++)
        {
            player1Board[i] = true;
        }
        
        for(int i = 0; i <  player2board.length; i++)
        {
             player2board[i] = true;
        }
        
    }
    
    
    
    private void buildLowerPanel()
    {
        
        bothPlayerPanel = new JPanel();
        bothPlayerPanel.setLayout(new GridLayout(1, 2));
        
        player1Panel = new JPanel();
        player1Panel.setBorder(BorderFactory.createTitledBorder("Player 1")); //creates the little border around the bottom left with a title
        player1Panel.setLayout(new GridLayout(2,2));
        player1Label = new JLabel("Player 1:");
        player1NameEnter = new JTextField("");
        player1Wins = new JLabel("WINS: "); //come back here to update
        player1Loss = new JLabel("LOSSES: "); //come back here to update
        
        
        player1Panel.add(player1Label); //goes top left to bottom right (like a book)
        player1Panel.add(player1NameEnter);
        player1Panel.add(player1Wins);
        player1Panel.add(player1Loss);
        
        
        player2Panel = new JPanel();
        player2Panel.setLayout(new GridLayout(2,2));
        player2Label = new JLabel("Player 2:");
        player2NameEnter = new JTextField("");
        player2Wins = new JLabel("WINS: "); //come back here to update
        player2Loss = new JLabel("LOSSES: "); //come back here to update
        
        player2Panel.add(player2Label); //goes top left to bottom right (like a book)
        player2Panel.add(player2NameEnter);
        player2Panel.add(player2Wins);
        player2Panel.add(player2Loss);
        
        bothPlayerPanel.add(player1Panel);
        bothPlayerPanel.add(player2Panel);
        
        
    }
    
    public void loadVideoGameInformation() //loads the images into the array videoGameCharactersImages
    {
        videoGameCharactersImages[0] = new ImageIcon("1commanderShepard.jpg");
        videoGameCharactersImages[1] = new ImageIcon("2ezioAuditore.jpg");
        videoGameCharactersImages[2] = new ImageIcon("3earthwormJim.jpg");
        videoGameCharactersImages[3] = new ImageIcon("4kidIcarus.jpg");
        videoGameCharactersImages[4] = new ImageIcon("5fargoth.jpg");
        videoGameCharactersImages[5] = new ImageIcon("6mccree.jpg");
        videoGameCharactersImages[6] = new ImageIcon("7handsomeJack.jpg");
        videoGameCharactersImages[7] = new ImageIcon("8rayman.jpg");
        videoGameCharactersImages[8] = new ImageIcon("9diddyKong.jpg");
        videoGameCharactersImages[9] = new ImageIcon("10spyro.jpg");
        videoGameCharactersImages[10] = new ImageIcon("11nathanDrake.jpg");
        videoGameCharactersImages[11] = new ImageIcon("12gordanFreeman.jpg");
        videoGameCharactersImages[12] = new ImageIcon("13glados.jpg");
        videoGameCharactersImages[13] = new ImageIcon("14samus.jpg");
        videoGameCharactersImages[14] = new ImageIcon("15agent47.jpg");
        videoGameCharactersImages[15] = new ImageIcon("16samFisher.jpg");
        videoGameCharactersImages[16] = new ImageIcon("17sonic.jpg");
        videoGameCharactersImages[17] = new ImageIcon("18banjoKazooie.jpg");
        videoGameCharactersImages[18] = new ImageIcon("19pikachu.jpg");
        videoGameCharactersImages[19] = new ImageIcon("20bowser.jpg");
        videoGameCharactersImages[20] = new ImageIcon("21megaMan.jpg");
        videoGameCharactersImages[21] = new ImageIcon("22kratos.jpg");
        videoGameCharactersImages[22] = new ImageIcon("23geralt.jpg");
        videoGameCharactersImages[23] = new ImageIcon("24laraCroft.jpg");
        videoGameCharactersImages[24] = new ImageIcon("25link.jpg");
        
        videoGameCharacterNames[0] = "Commander Shepard";
        videoGameCharacterNames[1] = "Ezio Auditore";
        videoGameCharacterNames[2] = "EarthWorm Jim";
        videoGameCharacterNames[3] = "Kid Icarus";
        videoGameCharacterNames[4] = "Fargoth";
        videoGameCharacterNames[5] = "McCree";
        videoGameCharacterNames[6] = "Handsome Jack";
        videoGameCharacterNames[7] = "Rayman";
        videoGameCharacterNames[8] = "Diddy Kong";
        videoGameCharacterNames[9] = "Spyro";
        videoGameCharacterNames[10] = "Nathan Drake";
        videoGameCharacterNames[11] = "Gordan Freeman";
        videoGameCharacterNames[12] = "GlADos";
        videoGameCharacterNames[13] = "Samus";
        videoGameCharacterNames[14] = "Agent 47";
        videoGameCharacterNames[15] = "Sam Fisher";
        videoGameCharacterNames[16] = "Sonic";
        videoGameCharacterNames[17] = "Banjo Kazooie";
        videoGameCharacterNames[18] = "Pikachu";
        videoGameCharacterNames[19] = "Bowser";
        videoGameCharacterNames[20] = "Megaman";
        videoGameCharacterNames[21] = "Kratos";
        videoGameCharacterNames[22] = "Geralt";
        videoGameCharacterNames[23] = "Lara Croft";
        videoGameCharacterNames[24] = "Link";
    }
    
    
    public void resetBoard() //resets the game board back to normal
    {
        for(int i = 0; i < gameBoardButtons.length; i++)
        {
            gameBoardButtons[i].setIcon(null);
            gameBoardButtons[i].setText(null);
        }
    }
    
    
    
    private class gameButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            
            String name = (e.getActionCommand());
            int count = 0;
            int saveCount = 0;
            for (int i = 0; i < gameBoardButtons.length; i++)
            {
                if(name.equals(videoGameCharacterNames[i]))
                {
                    saveCount = count;
                }
                count++;
            }
            if(player1Board[saveCount] == true)
            {
                
                shadeInOrNot(saveCount);
                player1Board[saveCount] = false;
            } else {
                
                shadeInOrNot(saveCount);
                player1Board[saveCount] = true;
            }
            
        }
    }
    
    public void shadeInOrNot(int position)
    {
        
        if(player1Board[position] == true)
        {
            gameBoardButtons[position].setBackground(Color.RED);
            System.out.println("AAAAAAA");
        } else {
            gameBoardButtons[position].setBackground(new JButton().getBackground());
        }
    } 
    
    
    
    private class startCancelButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == startGameButton)
            {
                if(classMatesRadioButton.isSelected())
                {
                    
                }
                
                else if(videoGameCharacterRadioButton.isSelected())
                {
                    for(int i = 0; i < gameBoardButtons.length; i++) //adds the buttons
                    {
                        
                        gameBoardButtons[i].setIcon(videoGameCharactersImages[i]);
                        gameBoardButtons[i].setText(videoGameCharacterNames[i]);
                        gameBoardButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
                        startGameButton.setEnabled(false);
                        pack();
                    }
                }
                
                else if(somethingRadioButton.isSelected())
                {
                    
                }
            }
            
            else if(e.getSource() == resetGameButton)
            {
                resetBoard();
                startGameButton.setEnabled(true);
            }
        }
    }
    
    public static void main(String[] args) {
        new GuessWhoProject2();
    }
    
}