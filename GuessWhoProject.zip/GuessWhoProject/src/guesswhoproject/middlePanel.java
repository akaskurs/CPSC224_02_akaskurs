/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners


public class middlePanel extends JPanel{
    
    private JButton[] classMates = new JButton[25]; // 5 x 5
    private ImageIcon[] classMatesImages = new ImageIcon[25];
    
    private JButton[] videoGameCharacters = new JButton[25];
    private ImageIcon[] videoGameCharactersImages = new ImageIcon[25];
    private String[] videoGameCharacterNames = new String[25];
    
    private JButton[] something = new JButton[25];
    private ImageIcon[] somethingImages = new ImageIcon[25];
    

    
    
    
    
    public void loadVideoGameInformation() //loads the images into the array videoGameCharactersImages
    {
        videoGameCharactersImages[0] = new ImageIcon("1commanderShepard.jpg");
        videoGameCharactersImages[1] = new ImageIcon("2ezioAuditore.jpg");
        videoGameCharactersImages[2] = new ImageIcon("3earthwormJim.jpg");
        videoGameCharactersImages[3] = new ImageIcon("4kidIcarus.jpg");
        videoGameCharactersImages[4] = new ImageIcon("5fargoth.jpg");
        videoGameCharactersImages[5] = new ImageIcon("6mccree.jpg");
        videoGameCharactersImages[6] = new ImageIcon("7handsomeJack.jpg");
        videoGameCharactersImages[7] = new ImageIcon("8rayman.jpg");
        videoGameCharactersImages[8] = new ImageIcon("9diddyKong.jpg");
        videoGameCharactersImages[9] = new ImageIcon("10spyro.jpg");
        videoGameCharactersImages[10] = new ImageIcon("11nathanDrake.jpg");
        videoGameCharactersImages[11] = new ImageIcon("12gordanFreeman.jpg");
        videoGameCharactersImages[12] = new ImageIcon("13glados.jpg");
        videoGameCharactersImages[13] = new ImageIcon("14samus.jpg");
        videoGameCharactersImages[14] = new ImageIcon("15agent47.jpg");
        videoGameCharactersImages[15] = new ImageIcon("16samFisher.jpg");
        videoGameCharactersImages[16] = new ImageIcon("17sonic.jpg");
        videoGameCharactersImages[17] = new ImageIcon("18banjoKazooie.jpg");
        videoGameCharactersImages[18] = new ImageIcon("19pikachu.jpg");
        videoGameCharactersImages[19] = new ImageIcon("20bowser.jpg");
        videoGameCharactersImages[20] = new ImageIcon("21megaMan.jpg");
        videoGameCharactersImages[21] = new ImageIcon("22kratos.jpg");
        videoGameCharactersImages[22] = new ImageIcon("23geralt.jpg");
        videoGameCharactersImages[23] = new ImageIcon("24laraCroft.jpg");
        videoGameCharactersImages[24] = new ImageIcon("25link.jpg");
        
        videoGameCharacterNames[0] = "Commander Shepard";
        videoGameCharacterNames[1] = "Ezio Auditore";
        videoGameCharacterNames[2] = "EarthWorm Jim";
        videoGameCharacterNames[3] = "Kid Icarus";
        videoGameCharacterNames[4] = "Fargoth";
        videoGameCharacterNames[5] = "McCree";
        videoGameCharacterNames[6] = "Handsome Jack";
        videoGameCharacterNames[7] = "Rayman";
        videoGameCharacterNames[8] = "Diddy Kong";
        videoGameCharacterNames[9] = "Spyro";
        videoGameCharacterNames[10] = "Nathan Drake";
        videoGameCharacterNames[11] = "Gordan Freeman";
        videoGameCharacterNames[12] = "GlADos";
        videoGameCharacterNames[13] = "Samus";
        videoGameCharacterNames[14] = "Agent 47";
        videoGameCharacterNames[15] = "Sam Fisher";
        videoGameCharacterNames[16] = "Sonic";
        videoGameCharacterNames[17] = "Banjo Kazooie";
        videoGameCharacterNames[18] = "Pikachu";
        videoGameCharacterNames[19] = "Bowser";
        videoGameCharacterNames[20] = "Megaman";
        videoGameCharacterNames[21] = "Kratos";
        videoGameCharacterNames[22] = "Geralt";
        videoGameCharacterNames[23] = "Lara Croft";
        videoGameCharacterNames[24] = "Link";
    }

    public middlePanel()
    {
        setLayout(new GridLayout(5, 5));
        loadVideoGameInformation();
    }
    
    public void loadVideoGameIntoBoard() //function loads the video game board to the main board!
    {
        for(int i = 0; i < videoGameCharacters.length; i++) //adds the buttons
        {
            videoGameCharacters[i] = new JButton();
            videoGameCharacters[i].setIcon(videoGameCharactersImages[i]);
            videoGameCharacters[i].setText(videoGameCharacterNames[i]);
            videoGameCharacters[i].setHorizontalAlignment(SwingConstants.LEFT);
            add(videoGameCharacters[i]);
        }
    }
    
    
    
    
    
}
