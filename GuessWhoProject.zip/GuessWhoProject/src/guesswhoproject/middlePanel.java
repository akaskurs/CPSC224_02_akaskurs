/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners


public class middlePanel extends JPanel{
    
    private JButton[] classMates = new JButton[25]; // 5 x 5


    public middlePanel()
    {
        setLayout(new GridLayout(5, 5));
        
        for(int i = 0; i < classMates.length; i++)
        {
            classMates[i] = new JButton();
            add(classMates[i]);
        }
        
        
    }
    
    
    
    
    
}
