/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners




public class lowerPanel extends JPanel{
    
    private JPanel player1Panel;
    private JPanel player2Panel;
    
    private JLabel player1Label;
    private JTextField player1NameEnter;
    private JLabel player1Wins;
    private JLabel player1Loss;
    
    private JLabel player2Label;
    private JTextField player2NameEnter;
    private JLabel player2Wins;
    private JLabel player2Loss;
    
    public lowerPanel()
    {
        setLayout(new GridLayout(1, 2));
        buildPlayer1Panel();
        buildPlayer2Panel();
        
        
        add(player1Panel);
        add(player2Panel);
        
        
        
        
        
        
        
    }
    
    private void buildPlayer1Panel()
    {
        player1Panel = new JPanel();
        player1Panel.setBorder(BorderFactory.createTitledBorder("Player 1")); //creates the little border around the bottom left with a title
        player1Panel.setLayout(new GridLayout(2,2));
        player1Label = new JLabel("Player 1:");
        player1NameEnter = new JTextField("");
        player1Wins = new JLabel("WINS: "); //come back here to update
        player1Loss = new JLabel("LOSSES: "); //come back here to update
        
        player1Panel.add(player1Label); //goes top left to bottom right (like a book)
        player1Panel.add(player1NameEnter);
        player1Panel.add(player1Wins);
        player1Panel.add(player1Loss);
    }
    
    private void buildPlayer2Panel()
    {
        player2Panel = new JPanel();
        player2Panel.setLayout(new GridLayout(2,2));
        player2Label = new JLabel("Player 2:");
        player2NameEnter = new JTextField("");
        player2Wins = new JLabel("WINS: "); //come back here to update
        player2Loss = new JLabel("LOSSES: "); //come back here to update
        
        player2Panel.add(player2Label); //goes top left to bottom right (like a book)
        player2Panel.add(player2NameEnter);
        player2Panel.add(player2Wins);
        player2Panel.add(player2Loss);
    }
    
    
    
    
}
