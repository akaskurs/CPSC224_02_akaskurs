/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners




public class upperPanel extends JPanel{
    
    private JRadioButton classMatesRadioButton;
    private JRadioButton videoGameCharacterRadioButton;
    private JRadioButton somethingRadioButton;
    private ButtonGroup gameVersionGroup; //allow only one of the options to be selected at a time (radio buttons).
    private JButton startGameButton;
    private JButton resetGameButton;
    
    
    public upperPanel()
    {
        setLayout(new GridLayout(1, 5));
        
        classMatesRadioButton = new JRadioButton("Class Mates");
        videoGameCharacterRadioButton = new JRadioButton("Video Game Characters");
        somethingRadioButton = new JRadioButton("something");
        
        
        
        gameVersionGroup = new ButtonGroup(); //creates a button group for our selection radio buttons
        gameVersionGroup.add(classMatesRadioButton); //adds the buttons to the group
        gameVersionGroup.add(videoGameCharacterRadioButton);
        gameVersionGroup.add(somethingRadioButton);
        
        startGameButton = new JButton("Start Game!");
        resetGameButton = new JButton("Reset Board!");
        
        //startGameButton.addActionListener(new myActionListener()); //adds the start button to the ActionListener class
        
        add(classMatesRadioButton);
        add(videoGameCharacterRadioButton);
        add(somethingRadioButton);
        add(startGameButton);
        add(resetGameButton);
          
    }
    
    
    
    
}
