/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guesswhoproject;
import javax.swing.*; //Allows for use of JFrame commands, objects etc.
import java.awt.*; //Allows for specific JFrame and JPanel layout managers
import java.awt.event.*; //handles ActionListener
import javax.swing.event.*; //handles ListsSelection events/listeners


public class GuessWhoProject extends JFrame{
    

    private upperPanel upPanel;
    private lowerPanel lowPanel;
    private middlePanel midPanel;
    
    
    public GuessWhoProject()
    {
        setTitle("Guess Who");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setVisible(true);
        upPanel = new upperPanel();
        lowPanel = new lowerPanel();
        midPanel = new middlePanel();
        add(upPanel, BorderLayout.NORTH);
        add(midPanel, BorderLayout.CENTER);
        add(lowPanel, BorderLayout.SOUTH);
        
        
        pack();
    }


    public static void main(String[] args) {
        new GuessWhoProject();
    }
    
}
